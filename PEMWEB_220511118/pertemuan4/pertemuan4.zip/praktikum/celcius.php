<?php
function celsiusToFahrenheit($celsius) {
return ($celsius * 9/5) + 32;
}
echo celsiusToFahrenheit(30); 
?>