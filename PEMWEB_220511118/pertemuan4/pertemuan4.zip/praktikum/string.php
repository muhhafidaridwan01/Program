<?php
function balikString($string) {
    return strrev($string);
    }
    echo balikString("PHP"); 
?>