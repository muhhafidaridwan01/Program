<?php
function luasPersegiPanjang($panjang, $lebar) {
return $panjang * $lebar;
}
echo luasPersegiPanjang(5, 10);
?>