<?php
function jamKeDetik($jam) {
    return $jam * 3600;
    }
    echo jamKeDetik(2);
?>