<?php
function sapaPengguna($nama) {
return "Halo, " . $nama . "! Selamat datang.";
}
echo sapaPengguna("Andi");
?>