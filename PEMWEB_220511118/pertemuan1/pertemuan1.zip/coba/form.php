<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>latihan3</title>
    <link rel="icon" type="image/x-icon" href="./assets/favicon.ico"/>
</head>

<body>
    <form name="form1" method="POST" action="hitung.php">
        Panjang : <input type="text" name="panjang" id="panjang"/><br/>
        Lebar : <input type="text" name="lebar" id="lebar"/><br/>
        <input type="submit" value="Hitung"/><br/>
    </form>
</body>
</html>