<?php
// Menyertakan file model KaryawanModel.php yang berisi fungsi-fungsi untuk mengelola data karyawan.
include_once('../models/KaryawanModel.php');

// Mendefinisikan kelas KaryawanController
class KaryawanController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model KaryawanModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new KaryawanModel();
    }

    // Fungsi untuk menambahkan karyawan baru ke dalam database
    public function addKaryawan($nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk)
    {
        // Memanggil fungsi addKaryawan() dari model untuk menambahkan data karyawan ke dalam database
        return $this->model->addKaryawan($nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk);
    }

    // Fungsi untuk mengambil data karyawan berdasarkan ID karyawan
    public function getKaryawan($id_karyawan)
    {
        // Memanggil fungsi getKaryawan() dari model untuk mengambil data karyawan berdasarkan ID
        return $this->model->getKaryawan($id_karyawan);
    }

    // Fungsi untuk menampilkan nama karyawan berdasarkan ID karyawan
    public function Show($id_karyawan)
    {
        // Mengambil data karyawan berdasarkan ID karyawan
        $rows = $this->model->getKaryawan($id_karyawan);
        $val = null;
        
        // Loop untuk mendapatkan nama karyawan dari data yang didapat
        foreach ($rows as $row) {
            $val = $row['nama_karyawan'];
        }
        
        // Mengembalikan nama karyawan
        return $val;
    }

    // Fungsi untuk memperbarui data karyawan di database berdasarkan ID karyawan
    public function updateKaryawan($id_karyawan, $nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk)
    {
        // Memanggil fungsi updateKaryawan() dari model untuk memperbarui data karyawan
        return $this->model->updateKaryawan($id_karyawan, $nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk);
    }

    // Fungsi untuk menghapus data karyawan berdasarkan ID karyawan
    public function deleteKaryawan($id_karyawan)
    {
        // Memanggil fungsi deleteKaryawan() dari model untuk menghapus data karyawan dari database
        return $this->model->deleteKaryawan($id_karyawan);
    }

    // Fungsi untuk mengambil daftar seluruh karyawan
    public function getKaryawanList()
    {
        // Memanggil fungsi getKaryawanList() dari model untuk mengambil semua data karyawan
        return $this->model->getKaryawanList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }
}
?>
