<?php
include_once('../db/database.php'); // Menyertakan file database untuk koneksi ke database

// Kelas KaryawanModel bertanggung jawab untuk melakukan operasi CRUD pada tabel 'karyawan' di database
class KaryawanModel
{
    private $db; // Properti untuk menyimpan objek koneksi database

    // Konstruktor kelas yang akan membuat objek koneksi ke database
    public function __construct()
    {
        $this->db = new Database(); // Membuat objek Database untuk koneksi ke DB
    }

    // Fungsi untuk menambahkan data karyawan baru ke database
    public function addKaryawan($nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk)
    {
        // Query SQL untuk menambahkan data karyawan baru
        $sql = "INSERT INTO karyawan (nik, nama_karyawan, jk, departemen, status, tgl_masuk) 
                VALUES (:nik, :nama_karyawan, :jk, :departemen, :status, :tgl_masuk)";
        
        // Parameter yang akan diganti pada query SQL
        $params = array(
            ":nik" => $nik,
            ":nama_karyawan" => $nama_karyawan,
            ":jk" => $jk,
            ":departemen" => $departemen,
            ":status" => $status,
            ":tgl_masuk" => $tgl_masuk,
        );

        // Eksekusi query dengan parameter yang telah diberikan
        $result = $this->db->executeQuery($sql, $params);
        
        // Mengecek apakah eksekusi berhasil dan mengembalikan hasil dalam format JSON
        if ($result) {
            return json_encode(array("success" => true, "message" => "Insert successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Insert failed"));
        }
    }

    // Fungsi untuk mengambil data karyawan berdasarkan id_karyawan
    public function getKaryawan($id_karyawan)
    {
        // Query SQL untuk mengambil data karyawan berdasarkan ID
        $sql = "SELECT * FROM karyawan WHERE id_karyawan = :id_karyawan";
        
        // Parameter untuk mencari berdasarkan id_karyawan
        $params = array(":id_karyawan" => $id_karyawan);
        
        // Mengembalikan data karyawan dalam bentuk array asosiatif
        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengupdate data karyawan berdasarkan id_karyawan
    public function updateKaryawan($id_karyawan, $nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk)
    {
        // Query SQL untuk memperbarui data karyawan
        $sql = "UPDATE karyawan 
                SET nik = :nik, nama_karyawan = :nama_karyawan, jk = :jk, 
                    departemen = :departemen, status = :status, tgl_masuk = :tgl_masuk
                WHERE id_karyawan = :id_karyawan";
        
        // Parameter yang akan digunakan untuk mengupdate data
        $params = array(
            ":nik" => $nik,
            ":nama_karyawan" => $nama_karyawan,
            ":jk" => $jk,
            ":departemen" => $departemen,
            ":status" => $status,
            ":tgl_masuk" => $tgl_masuk,
            ":id_karyawan" => $id_karyawan
        );

        // Eksekusi query update dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Update successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Update failed"));
        }
    }

    // Fungsi untuk menghapus data karyawan berdasarkan id_karyawan
    public function deleteKaryawan($id_karyawan)
    {
        // Query SQL untuk menghapus data karyawan berdasarkan ID
        $sql = "DELETE FROM karyawan WHERE id_karyawan = :id_karyawan";
        
        // Parameter untuk menghapus data berdasarkan id_karyawan
        $params = array(":id_karyawan" => $id_karyawan);
        
        // Eksekusi query delete dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Delete successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Delete failed"));
        }
    }

    // Fungsi untuk mengambil daftar seluruh karyawan
    public function getKaryawanList()
    {
        // Query SQL untuk mengambil semua data karyawan
        $sql = 'SELECT * FROM karyawan';
        
        // Mengembalikan hasil query dalam bentuk array asosiatif
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil data karyawan dan mengirimkannya dalam format JSON
    public function getDataCombo()
    {
        // Query SQL untuk mengambil semua data karyawan
        $sql = 'SELECT * FROM karyawan';
        
        // Mengambil hasil query
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        
        // Menetapkan header sebagai JSON dan mengirimkan data sebagai JSON
        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
?>
