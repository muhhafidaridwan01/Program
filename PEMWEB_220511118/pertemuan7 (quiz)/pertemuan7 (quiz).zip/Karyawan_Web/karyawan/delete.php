<?php
include("../controllers/Karyawan.php");
include("../lib/functions.php");

$obj = new KaryawanController();

// Mengambil ID Karyawan dari URL jika ada
$id_karyawan = null;
if (isset($_GET["id_karyawan"])) {
    $id_karyawan = $_GET["id_karyawan"];
}

$msg = null;
if (isset($_POST['submitted']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // Pastikan ID Karyawan diambil dari form POST
    if (isset($_POST['id_karyawan'])) {
        $id_karyawan = $_POST['id_karyawan'];
        $dat = $obj->deleteKaryawan($id_karyawan);
        $msg = getJSON($dat);
    }
}

// Mengambil data karyawan jika ID karyawan ada
$rows = $id_karyawan ? $obj->getKaryawan($id_karyawan) : [];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Data Karyawan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Custom Background Image */
        body {
            background-image: url('foto_pt.jpg');
            background-size: cover;
            background-position: center;
            font-family: 'Arial', sans-serif;
        }

        /* Container with border */
        .container {
            background-color: white; /* White solid background */
            border-radius: 10px;
            border: 2px solid #3B82F6; /* Blue border */
        }

        /* Custom blue background for rows */
        .row-blue {
            background-color: #ebf4ff; /* Light blue background */
        }
    </style>
</head>
<body class="bg-gray-100 p-6">

    <div class="max-w-4xl mx-auto p-6 rounded-lg shadow-md container">
        <h1 class="text-3xl font-bold mb-2 text-center text-blue-700">Karyawan</h1>
        <p class="text-gray-600 mb-4 text-center text-sm">Delete Data Karyawan</p>

        <?php 
        // Menampilkan pesan berhasil atau gagal
        if ($msg === true) { 
            echo '<div class="bg-green-500 text-white p-3 rounded mb-4">Delete Data Berhasil</div>';
        } elseif ($msg === false) {
            echo '<div class="bg-red-500 text-white p-3 rounded mb-4">Delete Gagal</div>'; 
        }
        ?>

        <div class="flex items-center mb-4">
            <h2 class="text-xl font-semibold">Hapus Data Karyawan</h2>
        </div>
        <hr class="mb-4"/>

        <form name="formDelete" method="POST" action="">
            <input type="hidden" name="submitted" value="1"/>
            
            <!-- Menampilkan data karyawan -->
            <div class="space-y-4">
                <?php if (!empty($rows)) : ?>
                    <?php foreach ($rows as $row): ?>
                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">ID Karyawan:</span>
                            <span class="text-gray-600"><?php echo $row['id_karyawan']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">NIK:</span>
                            <span class="text-gray-600"><?php echo $row['nik']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Nama Karyawan:</span>
                            <span class="text-gray-600"><?php echo $row['nama_karyawan']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Jenis Kelamin:</span>
                            <span class="text-gray-600"><?php echo $row['jk']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Departemen:</span>
                            <span class="text-gray-600"><?php echo $row['departemen']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Status:</span>
                            <span class="text-gray-600"><?php echo $row['status']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Tanggal Masuk:</span>
                            <span class="text-gray-600"><?php echo $row['tgl_masuk']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="text-gray-600">Data Karyawan tidak ditemukan.</p>
                <?php endif; ?>
            </div>

            <input type="hidden" name="id_karyawan" value="<?php echo isset($row['id_karyawan']) ? $row['id_karyawan'] : ''; ?>" />

            <div class="flex justify-between mt-4">
                <button type="submit" class="bg-red-500 text-white font-semibold py-2 px-4 rounded hover:bg-red-600">Delete</button>
                <!-- Tombol Cancel menuju halaman karyawan.php -->
                <a href="index.php" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400">Cancel</a>
            </div>
        </form>
    </div>

</body>
</html>
