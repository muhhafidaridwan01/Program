<?php
// Memasukkan file controller dan fungsi tambahan
include("../controllers/Karyawan.php");
include("../lib/functions.php");

// Membuat objek controller untuk Karyawan
$obj = new KaryawanController();

// Mengecek apakah ada parameter id_karyawan yang dikirimkan melalui URL
if (isset($_GET["id_karyawan"])) {
    $id_karyawan = $_GET["id_karyawan"];
} else {
    // Jika tidak ada, arahkan pengguna ke halaman edit.php
    header("Location: edit.php"); // Ganti dengan halaman yang sesuai
    exit; // Menghentikan eksekusi script setelah redirect
}

$msg = null; // Inisialisasi pesan kosong

// Mengecek apakah form telah disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $nik = $_POST["nik"];
    $nama_karyawan = $_POST["nama_karyawan"];
    $jk = $_POST["jk"];
    $departemen = $_POST["departemen"];
    $status = $_POST["status"];
    $tgl_masuk = $_POST["tgl_masuk"];
    
    // Memanggil fungsi untuk melakukan update data karyawan
    $dat = $obj->updateKaryawan($id_karyawan, $nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk);

    // Mengecek apakah update berhasil
    if ($dat) {
        $msg = 'Update Data Berhasil'; // Menampilkan pesan sukses
    } else {
        $msg = 'Update Gagal'; // Menampilkan pesan gagal
    }
}

// Mengambil data karyawan yang akan diedit
$rows = $obj->getKaryawan($id_karyawan);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Karyawan</title>
    <!-- Memasukkan TailwindCSS untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk menampilkan pesan sukses atau gagal selama 3 detik
        window.onload = function() {
            var msg = document.getElementById('msg');
            if (msg) {
                setTimeout(function() {
                    msg.style.display = 'none'; // Menyembunyikan pesan setelah 3 detik
                }, 3000);
            }
        };
    </script>
</head>
<body class="bg-cover bg-center bg-fixed" style="background-image: url('foto_pt.jpg');">
    <!-- Kontainer utama, memposisikan form di tengah layar -->
    <div class="flex justify-center items-center min-h-screen">
        <!-- Form untuk mengedit data karyawan -->
        <div class="max-w-xs w-full bg-white rounded-lg shadow-lg p-4">
            <h1 class="text-xl font-semibold text-center mb-3">Edit Karyawan</h1>
            <p class="text-gray-600 text-center mb-4 text-sm">Perbarui Data Karyawan</p>

            <!-- Menampilkan pesan setelah proses update -->
            <?php 
            if (isset($msg)) {
                echo '<div id="msg" class="bg-green-500 text-white p-3 rounded mb-4 text-center text-xs">' . $msg . '</div>';
            }
            ?>

            <!-- Form untuk mengedit data karyawan -->
            <form name="formEdit" method="POST" action="">
                <input type="hidden" name="submitted" value="1"/>
                <?php if ($rows) { $row = $rows[0]; ?>
                    <!-- Input ID Karyawan (readonly) -->
                    <div class="mb-3">
                        <label for="id_karyawan" class="block text-xs font-medium text-gray-700">ID Karyawan</label>
                        <input type="text" id="id_karyawan" name="id_karyawan" value="<?php echo $row['id_karyawan']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" readonly />
                    </div>

                    <!-- Input NIK -->
                    <div class="mb-3">
                        <label for="nik" class="block text-xs font-medium text-gray-700">NIK</label>
                        <input type="number" id="nik" name="nik" value="<?php echo $row['nik']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nama Karyawan -->
                    <div class="mb-3">
                        <label for="nama_karyawan" class="block text-xs font-medium text-gray-700">Nama Karyawan</label>
                        <input type="text" id="nama_karyawan" name="nama_karyawan" value="<?php echo $row['nama_karyawan']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Pilih Jenis Kelamin -->
                    <div class="mb-3">
                        <label for="jk" class="block text-xs font-medium text-gray-700">Jenis Kelamin</label>
                        <select name="jk" id="jk" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required>
                            <option value="L" <?php if ($row['jk'] == "L") echo "selected"; ?>>Laki-laki</option>
                            <option value="P" <?php if ($row['jk'] == "P") echo "selected"; ?>>Perempuan</option>
                        </select>
                    </div>

                    <!-- Pilih Departemen -->
                    <div class="mb-3">
                        <label for="departemen" class="block text-xs font-medium text-gray-700">Departemen</label>
                        <select id="departemen" name="departemen" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required>
                            <option value="IT" <?php if ($row['departemen'] == "IT") echo "selected"; ?>>IT</option>
                            <option value="SDA" <?php if ($row['departemen'] == "SDA") echo "selected"; ?>>SDA</option>
                            <option value="CS" <?php if ($row['departemen'] == "CS") echo "selected"; ?>>CS</option>
                        </select>
                    </div>

                    <!-- Pilih Status Karyawan -->
                    <div class="mb-3">
                        <label for="status" class="block text-xs font-medium text-gray-700">Status</label>
                        <select name="status" id="status" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required>
                            <option value="Tetap" <?php if ($row['status'] == "Tetap") echo "selected"; ?>>Tetap</option>
                            <option value="Kontrak" <?php if ($row['status'] == "Kontrak") echo "selected"; ?>>Kontrak</option>
                        </select>
                    </div>

                    <!-- Input Tanggal Masuk -->
                    <div class="mb-3">
                        <label for="tgl_masuk" class="block text-xs font-medium text-gray-700">Tanggal Masuk</label>
                        <input type="date" id="tgl_masuk" name="tgl_masuk" value="<?php echo $row['tgl_masuk']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Tombol Update -->
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md">Update</button>
                <?php } else { ?>
                    <!-- Jika data karyawan tidak ditemukan -->
                    <div class="text-red-500 text-center">Data Karyawan tidak ditemukan!</div>
                <?php } ?>

                <!-- Tombol Cancel untuk kembali ke halaman daftar karyawan -->
            </form>
        </div>
    </div>
</body>
</html>
