<?php
include("../controllers/Karyawan.php"); // Menyertakan file controller untuk Karyawan
include("../lib/functions.php"); // Menyertakan file library untuk fungsi tambahan
$obj = new KaryawanController(); // Membuat objek KaryawanController
$msg = null; // Menyimpan pesan yang akan ditampilkan

// Memproses form jika ada data POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data yang dikirim melalui form
    $nik = $_POST["nik"];
    $nama_karyawan = $_POST["nama_karyawan"];
    $jk = $_POST["jk"];
    $departemen = $_POST["departemen"];
    $status = $_POST["status"];
    $tgl_masuk = $_POST["tgl_masuk"];
    
    // Menyimpan data ke database melalui controller
    $dat = $obj->addKaryawan($nik, $nama_karyawan, $jk, $departemen, $status, $tgl_masuk);
    
    // Cek hasil dari proses insert data ke database
    if ($dat) {
        $msg = 'Insert Data Berhasil'; // Jika berhasil, tampilkan pesan sukses
    } else {
        $msg = 'Insert Gagal'; // Jika gagal, tampilkan pesan gagal
    }
}
?>

<html>
<head>
    <title>Karyawan</title> <!-- Judul halaman -->
    <script src="https://cdn.tailwindcss.com"></script> <!-- Menyertakan CDN Tailwind CSS untuk styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> <!-- Menyertakan CDN Font Awesome untuk ikon -->
    <script>
        // Fungsi untuk meng-clear form
        function clearForm() {
            document.forms["formAdd"].reset(); // Reset form untuk mengosongkan input
        }

        // Fungsi untuk menghilangkan pesan setelah beberapa detik
        function hideMessage() {
            setTimeout(function() {
                var messageElement = document.getElementById('message');
                if (messageElement) {
                    messageElement.style.display = 'none'; // Menyembunyikan pesan
                }
            }, 3000); // Menghilangkan pesan setelah 3 detik
        }
    </script>
</head>
<body class="bg-cover bg-center bg-fixed" style="background-image: url('foto_pt.jpg');"> <!-- Gambar latar belakang halaman -->
    <div class="flex justify-center items-center h-screen"> <!-- Menyusun form di tengah layar -->
        <!-- Form -->
        <div class="max-w-sm w-full bg-white rounded-lg shadow-lg p-4 ml-[145px]">
            <!-- Kotak form dengan sedikit margin kiri -->
            <h1 class="text-xl font-semibold text-center mb-3">Karyawan</h1> <!-- Judul form -->
            <p class="text-gray-600 text-center mb-4 text-sm">Entry Data</p> <!-- Keterangan form -->

            <!-- Menampilkan pesan sukses atau gagal -->
            <?php if ($msg): ?>
                <div id="message" class="bg-<?php echo ($msg == 'Insert Data Berhasil') ? 'green' : 'red'; ?>-500 text-white p-3 rounded mb-4 text-center text-xs">
                    <?php echo $msg; ?> <!-- Menampilkan pesan status -->
                </div>
                <script>
                    hideMessage(); // Memanggil fungsi untuk menyembunyikan pesan setelah beberapa detik
                </script>
            <?php endif; ?>

            <form name="formAdd" method="POST" action=""> <!-- Form untuk input data karyawan -->
                <div class="mb-3">
                    <label for="nik" class="block text-xs font-medium text-gray-700">NIK</label>
                    <input type="text" id="nik" name="nik" placeholder="Masukkan NIK" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk NIK -->
                </div>
                <div class="mb-3">
                    <label for="nama_karyawan" class="block text-xs font-medium text-gray-700">Nama Karyawan</label>
                    <input type="text" id="nama_karyawan" name="nama_karyawan" placeholder="Masukkan Nama Karyawan" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk nama karyawan -->
                </div>
                <div class="mb-3">
                    <label for="jk" class="block text-xs font-medium text-gray-700">Jenis Kelamin</label>
                    <select id="jk" name="jk" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required> <!-- Dropdown untuk jenis kelamin -->
                        <option value="">--Pilih Jenis Kelamin--</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="departemen" class="block text-xs font-medium text-gray-700">Departemen</label>
                    <select id="departemen" name="departemen" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required> <!-- Dropdown untuk departemen -->
                        <option value="">--Pilih Departemen--</option>
                        <option value="IT">IT</option>
                        <option value="SDA">SDA</option>
                        <option value="CS">CS</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="status" class="block text-xs font-medium text-gray-700">Status</label>
                    <select id="status" name="status" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required> <!-- Dropdown untuk status karyawan -->
                        <option value="">--Pilih Status--</option>
                        <option value="Tetap">Tetap</option>
                        <option value="Kontrak">Kontrak</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="tgl_masuk" class="block text-xs font-medium text-gray-700">Tanggal Masuk</label>
                    <input type="date" id="tgl_masuk" name="tgl_masuk" placeholder="Masukkan Tanggal Masuk" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk tanggal masuk -->
                </div>
                <div class="flex justify-between">
                    <button class="bg-blue-500 text-white font-semibold py-2 px-4 rounded hover:bg-blue-600 text-xs" type="submit">Save</button> <!-- Tombol untuk menyimpan data -->
                    <button type="button" onclick="clearForm()" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400 text-xs">Clear</button> <!-- Tombol untuk membersihkan form -->
                </div>
            </form>
        </div>
    </div>
</body>
</html>
