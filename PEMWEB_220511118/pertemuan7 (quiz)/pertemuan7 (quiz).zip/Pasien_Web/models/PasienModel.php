<?php
include_once('../db/database.php'); // Menyertakan file database untuk koneksi ke database

// Kelas PasienModel bertanggung jawab untuk melakukan operasi CRUD pada tabel 'pasien' di database
class PasienModel
{
    private $db; // Properti untuk menyimpan objek koneksi database

    // Konstruktor kelas yang akan membuat objek koneksi ke database
    public function __construct()
    {
        $this->db = new Database(); // Membuat objek Database untuk koneksi ke DB
    }

    // Fungsi untuk menambahkan data pasien baru ke database
    public function addPasien($no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat)
    {
        // Query SQL untuk menambahkan data pasien baru
        $sql = "INSERT INTO pasien (no_ktp, nama_pasien, jk, tgl_lahir, alamat) 
                VALUES (:no_ktp, :nama_pasien, :jk, :tgl_lahir, :alamat)";
        
        // Parameter yang akan diganti pada query SQL
        $params = array(
            ":no_ktp" => $no_ktp,
            ":nama_pasien" => $nama_pasien,
            ":jk" => $jk,
            ":tgl_lahir" => $tgl_lahir,
            ":alamat" => $alamat,
        );

        // Eksekusi query dengan parameter yang telah diberikan
        $result = $this->db->executeQuery($sql, $params);
        
        // Mengecek apakah eksekusi berhasil dan mengembalikan hasil dalam format JSON
        if ($result) {
            return json_encode(array("success" => true, "message" => "Insert successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Insert failed"));
        }
    }

    // Fungsi untuk mengambil data karyawan berdasarkan id_pasien
    public function getPasien($id_pasien)
    {
        // Query SQL untuk mengambil data pasien berdasarkan ID
        $sql = "SELECT * FROM pasien WHERE id_pasien = :id_pasien";
        
        // Parameter untuk mencari berdasarkan id_pasien
        $params = array(":id_pasien" => $id_pasien);
        
        // Mengembalikan data pasien dalam bentuk array asosiatif
        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengupdate data pasien berdasarkan id_pasien
    public function updatePasien($id_pasien, $no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat)
    {
        // Query SQL untuk memperbarui data pasien
        $sql = "UPDATE pasien 
                SET no_ktp = :no_ktp, nama_pasien = :nama_pasien, jk = :jk, 
                    tgl_lahir = :tgl_lahir, alamat = :alamat
                WHERE id_pasien = :id_pasien";
        
        // Parameter yang akan digunakan untuk mengupdate data
        $params = array(
            ":no_ktp" => $no_ktp,
            ":nama_pasien" => $nama_pasien,
            ":jk" => $jk,
            ":tgl_lahir" => $tgl_lahir,
            ":alamat" => $alamat,
            ":id_pasien" => $id_pasien
        );

        // Eksekusi query update dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Update successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Update failed"));
        }
    }

    // Fungsi untuk menghapus data pasien berdasarkan id_pasien
    public function deletePasien($id_pasien)
    {
        // Query SQL untuk menghapus data pasien berdasarkan ID
        $sql = "DELETE FROM pasien WHERE id_pasien = :id_pasien";
        
        // Parameter untuk menghapus data berdasarkan id_pasien
        $params = array(":id_pasien" => $id_pasien);
        
        // Eksekusi query delete dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Delete successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Delete failed"));
        }
    }

    // Fungsi untuk mengambil daftar seluruh pasien
    public function getPasienList()
    {
        // Query SQL untuk mengambil semua data pasien
        $sql = 'SELECT * FROM pasien';
        
        // Mengembalikan hasil query dalam bentuk array asosiatif
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil data pasien dan mengirimkannya dalam format JSON
    public function getDataCombo()
    {
        // Query SQL untuk mengambil semua data pasien
        $sql = 'SELECT * FROM pasien';
        
        // Mengambil hasil query
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        
        // Menetapkan header sebagai JSON dan mengirimkan data sebagai JSON
        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
?>
