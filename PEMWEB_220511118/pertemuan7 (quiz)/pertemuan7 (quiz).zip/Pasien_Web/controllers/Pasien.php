<?php
// Menyertakan file model PasienModel.php yang berisi fungsi-fungsi untuk mengelola data Pasien.
include_once('../models/PasienModel.php');

// Mendefinisikan kelas PasienController
class PasienController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model PasienModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new PasienModel();
    }

    // Fungsi untuk menambahkan Pasien baru ke dalam database
    public function addPasien($no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat)
    {
        // Memanggil fungsi addPasien() dari model untuk menambahkan data Pasien ke dalam database
        return $this->model->addPasien($no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat);
    }

    // Fungsi untuk mengambil data pasien berdasarkan ID pasien
    public function getPasien($id_pasien)
    {
        // Memanggil fungsi getPasien() dari model untuk mengambil data pasien berdasarkan ID
        return $this->model->getPasien($id_pasien);
    }

    // Fungsi untuk menampilkan nama pasien berdasarkan ID pasien
    public function Show($id_pasien)
    {
        // Mengambil data pasien berdasarkan ID pasien
        $rows = $this->model->getPasien($id_pasien);
        $val = null;
        
        // Loop untuk mendapatkan nama pasien dari data yang didapat
        foreach ($rows as $row) {
            $val = $row['nama_pasien'];
        }
        
        // Mengembalikan nama pasien
        return $val;
    }

    // Fungsi untuk memperbarui data pasien di database berdasarkan ID pasien
    public function updatePasien($id_pasien, $no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat)
    {
        // Memanggil fungsi updatepasien() dari model untuk memperbarui data pasien
        return $this->model->updatePasien($id_pasien, $no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat);
    }

    // Fungsi untuk menghapus data pasien berdasarkan ID pasien
    public function deletePasien($id_pasien)
    {
        // Memanggil fungsi deletepasien() dari model untuk menghapus data pasien dari database
        return $this->model->deletePasien($id_pasien);
    }

    // Fungsi untuk mengambil daftar seluruh pasien
    public function getPasienList()
    {
        // Memanggil fungsi getpasienList() dari model untuk mengambil semua data pasien
        return $this->model->getPasienList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }
}
?>
