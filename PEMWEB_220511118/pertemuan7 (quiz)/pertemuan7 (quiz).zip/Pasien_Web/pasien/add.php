<?php
include("../controllers/Pasien.php"); // Menyertakan file controller untuk Pasien
include("../lib/functions.php"); // Menyertakan file library untuk fungsi tambahan
$obj = new PasienController(); // Membuat objek KaryawanController
$msg = null; // Menyimpan pesan yang akan ditampilkan

// Memproses form jika ada data POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data yang dikirim melalui form
    $no_ktp = $_POST["no_ktp"];
    $nama_pasien = $_POST["nama_pasien"];
    $jk = $_POST["jk"];
    $tgl_lahir = $_POST["tgl_lahir"];
    $alamat = $_POST["alamat"];
    
    // Menyimpan data ke database melalui controller
    $dat = $obj->addPasien($no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat);
    
    // Cek hasil dari proses insert data ke database
    if ($dat) {
        $msg = 'Insert Data Berhasil'; // Jika berhasil, tampilkan pesan sukses
    } else {
        $msg = 'Insert Gagal'; // Jika gagal, tampilkan pesan gagal
    }
}
?>

<html>
<head>
    <title>Pasien</title> <!-- Judul halaman -->
    <script src="https://cdn.tailwindcss.com"></script> <!-- Menyertakan CDN Tailwind CSS untuk styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> <!-- Menyertakan CDN Font Awesome untuk ikon -->
    <script>
        // Fungsi untuk meng-clear form
        function clearForm() {
            document.forms["formAdd"].reset(); // Reset form untuk mengosongkan input
        }

        // Fungsi untuk menghilangkan pesan setelah beberapa detik
        function hideMessage() {
            setTimeout(function() {
                var messageElement = document.getElementById('message');
                if (messageElement) {
                    messageElement.style.display = 'none'; // Menyembunyikan pesan
                }
            }, 2000); // Menghilangkan pesan setelah 2 detik
        }
    </script>
</head>
<body class="bg-cover bg-center bg-fixed" style="background-image: url('rs.jpg');"> <!-- Gambar latar belakang halaman -->
    <div class="flex justify-center items-center h-screen"> <!-- Menyusun form di tengah layar -->
        <!-- Form -->
        <div class="max-w-sm w-full bg-white rounded-lg shadow-lg p-4 ml-[145px]">
            <!-- Kotak form dengan sedikit margin kiri -->
            <h1 class="text-xl font-semibold text-center mb-3">Pasien</h1> <!-- Judul form -->
            <p class="text-gray-600 text-center mb-4 text-sm">Entry Data</p> <!-- Keterangan form -->

            <!-- Menampilkan pesan sukses atau gagal -->
            <?php if ($msg): ?>
                <div id="message" class="bg-<?php echo ($msg == 'Insert Data Berhasil') ? 'green' : 'red'; ?>-500 text-white p-3 rounded mb-4 text-center text-xs">
                    <?php echo $msg; ?> <!-- Menampilkan pesan status -->
                </div>
                <script>
                    hideMessage(); // Memanggil fungsi untuk menyembunyikan pesan setelah beberapa detik
                </script>
            <?php endif; ?>

            <form name="formAdd" method="POST" action=""> <!-- Form untuk input data karyawan -->
                <div class="mb-3">
                    <label for="no_ktp" class="block text-xs font-medium text-gray-700">No. KTP</label>
                    <input type="text" id="no_ktp" name="no_ktp" placeholder="Masukkan Nomor KTP" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk NIK -->
                </div>
                <div class="mb-3">
                    <label for="nama_pasien" class="block text-xs font-medium text-gray-700">Nama Pasien</label>
                    <input type="text" id="nama_pasien" name="nama_pasien" placeholder="Masukkan Nama Pasien" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk nama karyawan -->
                </div>
                <div class="mb-3">
                    <label for="jk" class="block text-xs font-medium text-gray-700">Jenis Kelamin</label>
                    <select id="jk" name="jk" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required> <!-- Dropdown untuk jenis kelamin -->
                        <option value="">--Pilih Jenis Kelamin--</option>
                        <option value="L">Laki-laki</option>
                        <option value="P">Perempuan</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="tgl_lahir" class="block text-xs font-medium text-gray-700">Tanggal Lahir</label>
                    <input type="date" id="tgl_lahir" name="tgl_lahir" placeholder="Masukkan Tanggal lahir" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk tanggal masuk -->
                </div>
                <div class="mb-3">
                    <label for="alamat" class="block text-xs font-medium text-gray-700">Alamat</label>
                    <input type="text" id="alamat" name="alamat" placeholder="Masukkan Alamat" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk alamat -->
                </div>
                <div class="flex justify-between">
                    <button class="bg-blue-500 text-white font-semibold py-2 px-4 rounded hover:bg-blue-600 text-xs" type="submit">Save</button> <!-- Tombol untuk menyimpan data -->
                    <button type="button" onclick="clearForm()" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400 text-xs">Clear</button> <!-- Tombol untuk membersihkan form -->
                </div>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
