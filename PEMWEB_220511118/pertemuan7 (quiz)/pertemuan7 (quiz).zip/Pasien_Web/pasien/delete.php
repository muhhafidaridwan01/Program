<?php
include("../controllers/Pasien.php");
include("../lib/functions.php");

$obj = new PasienController();

// Mengambil ID Pasien dari URL jika ada
$id_pasien = null;
if (isset($_GET["id_pasien"])) {
    $id_pasien = $_GET["id_pasien"];
}

$msg = null;
if (isset($_POST['submitted']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // Pastikan ID pasien diambil dari form POST
    if (isset($_POST['id_pasien'])) {
        $id_pasien = $_POST['id_pasien'];
        $dat = $obj->deletePasien($id_pasien);
        $msg = getJSON($dat);
    }
}

// Mengambil data pasien jika ID pasien ada
$rows = $id_pasien ? $obj->getPasien($id_pasien) : [];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Data Pasien</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Custom Background Image */
        body {
            background-image: url('rs.jpg');
            background-size: cover;
            background-position: center;
            font-family: 'Arial', sans-serif;
        }

        /* Container with border */
        .container {
            background-color: white; /* White solid background */
            border-radius: 10px;
            border: 2px solid #3B82F6; /* Blue border */
        }

        /* Custom blue background for rows */
        .row-blue {
            background-color: #ebf4ff; /* Light blue background */
        }
    </style>
</head>
<body class="bg-gray-100 p-6">

    <div class="max-w-4xl mx-auto p-6 rounded-lg shadow-md container">
        <h1 class="text-3xl font-bold mb-2 text-center text-blue-700">Pasien</h1>
        <p class="text-gray-600 mb-4 text-center text-sm">Delete Data Pasien</p>

        <?php 
        // Menampilkan pesan berhasil atau gagal
        if ($msg === true) { 
            echo '<div class="bg-green-500 text-white p-3 rounded mb-4">Delete Data Berhasil</div>';
        } elseif ($msg === false) {
            echo '<div class="bg-red-500 text-white p-3 rounded mb-4">Delete Gagal</div>'; 
        }
        ?>

        <div class="flex items-center mb-4">
            <h2 class="text-xl font-semibold">Hapus Data Pasien</h2>
        </div>
        <hr class="mb-4"/>

        <form name="formDelete" method="POST" action="">
            <input type="hidden" name="submitted" value="1"/>
            
            <!-- Menampilkan data Pasien -->
            <div class="space-y-4">
                <?php if (!empty($rows)) : ?>
                    <?php foreach ($rows as $row): ?>
                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">ID</span>
                            <span class="text-gray-600"><?php echo $row['id_pasien']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Nomor KTP</span>
                            <span class="text-gray-600"><?php echo $row['no_ktp']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Nama Pasien</span>
                            <span class="text-gray-600"><?php echo $row['nama_pasien']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Jenis Kelamin</span>
                            <span class="text-gray-600"><?php echo $row['jk']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Tanggal Lahir</span>
                            <span class="text-gray-600"><?php echo $row['tgl_lahir']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Alamat</span>
                            <span class="text-gray-600"><?php echo $row['alamat']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="text-gray-600">Data Pasien tidak ditemukan.</p>
                <?php endif; ?>
            </div>

            <input type="hidden" name="id_pasien" value="<?php echo isset($row['id_pasien']) ? $row['id_pasien'] : ''; ?>" />

            <div class="flex justify-between mt-4">
                <button type="submit" class="bg-red-500 text-white font-semibold py-2 px-4 rounded hover:bg-red-600">Delete</button>
                <!-- Tombol Cancel menuju halaman Pasien.php -->
                <a href="index.php" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400">Cancel</a>
            </div>
        </form>
    </div>

</body>
</html>
