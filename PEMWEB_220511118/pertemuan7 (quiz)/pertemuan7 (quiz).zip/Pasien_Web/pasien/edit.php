<?php
// Memasukkan file controller dan fungsi tambahan
include("../controllers/Pasien.php");
include("../lib/functions.php");

// Membuat objek controller untuk Pasien
$obj = new PasienController();

// Mengecek apakah ada parameter id_pasien yang dikirimkan melalui URL
if (isset($_GET["id_pasien"])) {
    $id_pasien = $_GET["id_pasien"];
} else {
    // Jika tidak ada, arahkan pengguna ke halaman edit.php
    header("Location: edit.php"); // Ganti dengan halaman yang sesuai
    exit; // Menghentikan eksekusi script setelah redirect
}

$msg = null; // Inisialisasi pesan kosong

// Mengecek apakah form telah disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $no_ktp = $_POST["no_ktp"];
    $nama_pasien = $_POST["nama_pasien"];
    $jk = $_POST["jk"];
    $tgl_lahir = $_POST["tgl_lahir"];
    $alamat = $_POST["alamat"];
    
    // Memanggil fungsi untuk melakukan update data pasien
    $dat = $obj->updatePasien($id_pasien, $no_ktp, $nama_pasien, $jk, $tgl_lahir, $alamat);

    // Mengecek apakah update berhasil
    if ($dat) {
        $msg = 'Update Data Berhasil'; // Menampilkan pesan sukses
    } else {
        $msg = 'Update Gagal'; // Menampilkan pesan gagal
    }
}

// Mengambil data pasien yang akan diedit
$rows = $obj->getPasien($id_pasien);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Pasien</title>
    <!-- Memasukkan TailwindCSS untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk menampilkan pesan sukses atau gagal selama 3 detik
        window.onload = function() {
            var msg = document.getElementById('msg');
            if (msg) {
                setTimeout(function() {
                    msg.style.display = 'none'; // Menyembunyikan pesan setelah 3 detik
                }, 3000);
            }
        };
    </script>
</head>
<body class="bg-cover bg-center bg-fixed" style="background-image: url('rs.jpg');">
    <!-- Kontainer utama, memposisikan form di tengah layar -->
    <div class="flex justify-center items-center min-h-screen">
        <!-- Form untuk mengedit data pasien -->
        <div class="max-w-xs w-full bg-white rounded-lg shadow-lg p-4">
            <h1 class="text-xl font-semibold text-center mb-3">Edit Pasien</h1>
            <p class="text-gray-600 text-center mb-4 text-sm">Perbarui Data Pasien</p>

            <!-- Menampilkan pesan setelah proses update -->
            <?php 
            if (isset($msg)) {
                echo '<div id="msg" class="bg-green-500 text-white p-3 rounded mb-4 text-center text-xs">' . $msg . '</div>';
            }
            ?>

            <!-- Form untuk mengedit data pasien -->
            <form name="formEdit" method="POST" action="">
                <input type="hidden" name="submitted" value="1"/>
                <?php if ($rows) { $row = $rows[0]; ?>
                    <!-- Input ID pasien (readonly) -->
                    <div class="mb-3">
                        <label for="id_pasien" class="block text-xs font-medium text-gray-700">ID Pasien</label>
                        <input type="numer" id="id_pasien" name="id_pasien" value="<?php echo $row['id_pasien']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" readonly />
                    </div>

                    <!-- Input NO. KTP -->
                    <div class="mb-3">
                        <label for="no_ktp" class="block text-xs font-medium text-gray-700">No. KTP</label>
                        <input type="number" id="no_ktp" name="no_ktp" value="<?php echo $row['no_ktp']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nama pasien -->
                    <div class="mb-3">
                        <label for="nama_pasien" class="block text-xs font-medium text-gray-700">Nama Pasien</label>
                        <input type="text" id="nama_pasien" name="nama_pasien" value="<?php echo $row['nama_pasien']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Pilih Jenis Kelamin -->
                    <div class="mb-3">
                        <label for="jk" class="block text-xs font-medium text-gray-700">Jenis Kelamin</label>
                        <select name="jk" id="jk" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required>
                            <option value="L" <?php if ($row['jk'] == "L") echo "selected"; ?>>Laki-laki</option>
                            <option value="P" <?php if ($row['jk'] == "P") echo "selected"; ?>>Perempuan</option>
                        </select>
                    </div>

                    <!-- Input Tanggal Lahir -->
                    <div class="mb-3">
                        <label for="tgl_lahir" class="block text-xs font-medium text-gray-700">Tanggal Lahir</label>
                        <input type="date" id="tgl_lahir" name="tgl_lahir" value="<?php echo $row['tgl_lahir']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Alamat -->
                    <div class="mb-3">
                        <label for="alamat" class="block text-xs font-medium text-gray-700">Alamat</label>
                        <input type="text" id="alamat" name="alamat" value="<?php echo $row['alamat']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Tombol Update -->
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md">Update</button>
                <?php } else { ?>
                    <!-- Jika data karyawan tidak ditemukan -->
                    <div class="text-red-500 text-center">Data Pasien tidak ditemukan!</div>
                <?php } ?>

                <!-- Tombol Cancel untuk kembali ke halaman daftar pasien -->
            </form>
        </div>
    </div>
</body>
</html>
