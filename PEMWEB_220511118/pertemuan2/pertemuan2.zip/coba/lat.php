<?php 
$nilai = 70;
if($nilai>=60){
    echo("Anda lulus.");
} else{
    echo("Anda tidak lulus.");
}
echo("<br/>");
echo("Selesai.");
?>