<?php
include_once('../db/database.php');
$db = new Database();
$sql = "select * from dokter ";
$sql = 'SELECT * FROM dokter';
$result = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
header('Content-type: application/json');
echo json_encode($result);
?>