<?php

include_once('../db/database.php');

class ObatModel
{
    private $db;

    public function __construct()
    {
        $this->db = new Database();
    }

    public function addObat($kode_obat, $nama_obat, $produsen, $bentuk, $berat)
    {
        $sql = "INSERT INTO obat (kode_obat, nama_obat, produsen, bentuk, berat) 
                VALUES (:kode_obat, :nama_obat, :produsen, :bentuk, :berat)";
        $params = array(
            ":kode_obat" => $kode_obat,
            ":nama_obat" => $nama_obat,
            ":produsen" => $produsen,
            ":bentuk" => $bentuk,
            ":berat" => $berat
        );

        $result = $this->db->executeQuery($sql, $params);
        // Check if the insert was successful
        if ($result) {
            $response = array(
                "success" => true,
                "message" => "Insert successful"
            );
        } else {
            $response = array(
                "success" => false,
                "message" => "Insert failed"
            );
        }

        // Return the response as JSON
        return json_encode($response);
    }

    public function getObat($id)
    {
        $sql = "SELECT * FROM obat WHERE id = :id";
        $params = array(":id" => $id);

        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function updateObat($id, $kode_obat, $nama_obat, $produsen, $bentuk, $berat)
    {
        $sql = "UPDATE obat 
                SET kode_obat = :kode_obat, nama_obat = :nama_obat, produsen = :produsen, 
                    bentuk = :bentuk, berat = :berat 
                WHERE id = :id";
        $params = array(
            ":kode_obat" => $kode_obat,
            ":nama_obat" => $nama_obat,
            ":produsen" => $produsen,
            ":bentuk" => $bentuk,
            ":berat" => $berat,
            ":id" => $id
        );

        // Execute the query
        $result = $this->db->executeQuery($sql, $params);

        // Check if the update was successful
        if ($result) {
            $response = array(
                "success" => true,
                "message" => "Update successful"
            );
        } else {
            $response = array(
                "success" => false,
                "message" => "Update failed"
            );
        }

        // Return the response as JSON
        return json_encode($response);
    }

    public function deleteObat($id)
    {
        $sql = "DELETE FROM obat WHERE id = :id";
        $params = array(":id" => $id);

        $result = $this->db->executeQuery($sql, $params);
        // Check if the delete was successful
        if ($result) {
            $response = array(
                "success" => true,
                "message" => "Delete successful"
            );
        } else {
            $response = array(
                "success" => false,
                "message" => "Delete failed"
            );
        }

        // Return the response as JSON
        return json_encode($response);
    }

    public function getObatList()
    {
        $sql = 'SELECT * FROM obat';
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDataCombo()
    {
        $sql = 'SELECT * FROM obat';
        $data = array();
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
