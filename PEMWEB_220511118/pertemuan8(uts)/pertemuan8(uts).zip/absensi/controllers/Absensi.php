<?php
// Menyertakan file model AbsensiModel.php yang berisi fungsi-fungsi untuk mengelola data absensi.
include_once('../models/AbsensiModel.php');

// Mendefinisikan kelas AbsensiController
class AbsensiController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model AbsensiModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new AbsensiModel();
    }

    // Fungsi untuk menambahkan data absensi baru ke dalam database
    public function addAbsensi($kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Memanggil fungsi addAbsensi() dari model untuk menambahkan data absensi ke dalam database
        return $this->model->addAbsensi($kodemk, $matakuliah, $pertemuanke, $topik);
    }

    // Fungsi untuk mengambil data absensi berdasarkan ID
    public function getAbsensi($id)
    {
        // Memanggil fungsi getAbsensi() dari model untuk mengambil data absensi berdasarkan ID
        return $this->model->getAbsensi($id);
    }

    // Fungsi untuk memperbarui data absensi di database berdasarkan ID absensi
    public function updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Memanggil fungsi updateAbsensi() dari model untuk memperbarui data absensi
        return $this->model->updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik);
    }

    // Fungsi untuk menghapus data absensi berdasarkan ID absensi
    public function deleteAbsensi($id)
    {
        // Memanggil fungsi deleteAbsensi() dari model untuk menghapus data absensi dari database
        return $this->model->deleteAbsensi($id);
    }

    // Fungsi untuk mengambil daftar seluruh absensi
    public function getAbsensiList()
    {
        // Memanggil fungsi getAbsensiList() dari model untuk mengambil semua data absensi
        return $this->model->getAbsensiList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }
}
?>

<!-- HTML untuk halaman absensi -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-cover bg-center bg-fixed" style="background-image: url('foto_pt.jpg');">
    <div class="bg-gray-100 bg-opacity-50 p-6 min-h-screen">
        <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-3xl font-bold mb-4 text-center">Daftar Absensi</h1>
            <p class="text-gray-600 text-center mb-6">List Data Absensi</p>

            <!-- Tombol untuk menambah data absensi -->
            <a class="bg-green-500 text-white px-5 py-2 rounded shadow-md mb-4 inline-block hover:bg-green-600 transition duration-300" href="add_absensi.php">
                Tambah Data
            </a>

            <!-- Tabel untuk menampilkan data absensi -->
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-blue-500 rounded-lg shadow-md">
                    <thead class="bg-blue-200">
                        <tr>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">ID</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Kode MK</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Mata Kuliah</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Pertemuan Ke</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Topik</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-center">Aksi</th> <!-- Kolom aksi (edit/hapus) -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        // Membuat objek AbsensiController
                        $obj = new AbsensiController();
                        $rows = $obj->getAbsensiList(); // Mengambil daftar absensi dari controller
                        foreach ($rows as $row) { 
                        ?>
                            <tr class="bg-white hover:bg-gray-100 transition duration-200">
                                <!-- Menampilkan setiap data absensi dalam baris tabel -->
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['id']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['kodemk']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['matakuliah']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['pertemuanke']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['topik']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500 text-center">
                                    <div class="flex space-x-6 justify-center">
                                        <!-- Tombol untuk Edit data absensi -->
                                        <a class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition duration-300" href="edit_absensi.php?id=<?php echo $row['id']; ?>">
                                            Edit
                                        </a>
                                        <!-- Tombol untuk Hapus data absensi -->
                                        <a class="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700 transition duration-300" href="delete_absensi.php?id=<?php echo $row['id']; ?>">
                                            Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
