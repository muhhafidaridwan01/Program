<?php
include("../controllers/Absensi.php");
include("../lib/functions.php");

$obj = new AbsensiController();

// Mengambil ID Absensi dari URL jika ada
$id = null;
if (isset($_GET["id"])) {
    $id = $_GET["id"];
}

$msg = null;
if (isset($_POST['submitted']) && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // Pastikan ID Absensi diambil dari form POST
    if (isset($_POST['id'])) {
        $id = $_POST['id'];
        $dat = $obj->deleteAbsensi($id);
        $msg = getJSON($dat);
    }
}

// Mengambil data absensi jika ID absensi ada
$rows = $id ? $obj->getAbsensi($id) : [];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Data Absensi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-image: url('background.jpg');
            background-size: cover;
            background-position: center;
            font-family: 'Arial', sans-serif;
        }

        .container {
            background-color: white;
            border-radius: 10px;
            border: 2px solid #3B82F6;
        }

        .row-blue {
            background-color: #ebf4ff;
        }
    </style>
</head>
<body class="bg-gray-100 p-6">

    <div class="max-w-4xl mx-auto p-6 rounded-lg shadow-md container">
        <h1 class="text-3xl font-bold mb-2 text-center text-blue-700">Absensi</h1>
        <p class="text-gray-600 mb-4 text-center text-sm">Delete Data Absensi</p>

        <?php 
        if ($msg === true) { 
            echo '<div class="bg-green-500 text-white p-3 rounded mb-4">Delete Data Berhasil</div>';
        } elseif ($msg === false) {
            echo '<div class="bg-red-500 text-white p-3 rounded mb-4">Delete Gagal</div>'; 
        }
        ?>

        <div class="flex items-center mb-4">
            <h2 class="text-xl font-semibold">Hapus Data Absensi</h2>
        </div>
        <hr class="mb-4"/>

        <form name="formDelete" method="POST" action="">
            <input type="hidden" name="submitted" value="1"/>

            <div class="space-y-4">
                <?php if (!empty($rows)) : ?>
                    <?php foreach ($rows as $row): ?>
                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">ID:</span>
                            <span class="text-gray-600"><?php echo $row['id']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Kode MK:</span>
                            <span class="text-gray-600"><?php echo $row['kodemk']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Mata Kuliah:</span>
                            <span class="text-gray-600"><?php echo $row['matakuliah']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Pertemuan Ke:</span>
                            <span class="text-gray-600"><?php echo $row['pertemuanke']; ?></span>
                        </div>

                        <div class="flex justify-between items-center row-blue p-2 rounded">
                            <span class="font-medium text-gray-700">Topik:</span>
                            <span class="text-gray-600"><?php echo $row['topik']; ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php else : ?>
                    <p class="text-gray-600">Data Absensi tidak ditemukan.</p>
                <?php endif; ?>
            </div>

            <input type="hidden" name="id" value="<?php echo isset($row['id']) ? $row['id'] : ''; ?>" />

            <div class="flex justify-between mt-4">
                <button type="submit" class="bg-red-500 text-white font-semibold py-2 px-4 rounded hover:bg-red-600">Delete</button>
                <a href="index.php" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400">Cancel</a>
            </div>
        </form>
    </div>

</body>
</html>
