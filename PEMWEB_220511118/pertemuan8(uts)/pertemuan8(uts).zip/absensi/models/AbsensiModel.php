<?php
include_once('../db/database.php'); // Menyertakan file database untuk koneksi ke database

// Kelas AbsensiModel bertanggung jawab untuk melakukan operasi CRUD pada tabel 'absensi' di database
class AbsensiModel
{
    private $db; // Properti untuk menyimpan objek koneksi database

    // Konstruktor kelas yang akan membuat objek koneksi ke database
    public function __construct()
    {
        $this->db = new Database(); // Membuat objek Database untuk koneksi ke DB
    }

    // Fungsi untuk menambahkan data absensi baru ke database
    public function addAbsensi($kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Query SQL untuk menambahkan data absensi baru
        $sql = "INSERT INTO absensi (kodemk, matakuliah, pertemuanke, topik) 
                VALUES (:kodemk, :matakuliah, :pertemuanke, :topik)";
        
        // Parameter yang akan diganti pada query SQL
        $params = array(
            ":kodemk" => $kodemk,
            ":matakuliah" => $matakuliah,
            ":pertemuanke" => $pertemuanke,
            ":topik" => $topik,
        );

        // Eksekusi query dengan parameter yang telah diberikan
        $result = $this->db->executeQuery($sql, $params);
        
        // Mengecek apakah eksekusi berhasil dan mengembalikan hasil dalam format JSON
        if ($result) {
            return json_encode(array("success" => true, "message" => "Insert successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Insert failed"));
        }
    }

    // Fungsi untuk mengambil data absensi berdasarkan id
    public function getAbsensi($id)
    {
        // Query SQL untuk mengambil data absensi berdasarkan ID
        $sql = "SELECT * FROM absensi WHERE id = :id";
        
        // Parameter untuk mencari berdasarkan id
        $params = array(":id" => $id);
        
        // Mengembalikan data absensi dalam bentuk array asosiatif
        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengupdate data absensi berdasarkan id
    public function updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Query SQL untuk memperbarui data absensi
        $sql = "UPDATE absensi 
                SET kodemk = :kodemk, matakuliah = :matakuliah, pertemuanke = :pertemuanke, 
                    topik = :topik
                WHERE id = :id";
        
        // Parameter yang akan digunakan untuk mengupdate data
        $params = array(
            ":kodemk" => $kodemk,
            ":matakuliah" => $matakuliah,
            ":pertemuanke" => $pertemuanke,
            ":topik" => $topik,
            ":id" => $id
        );

        // Eksekusi query update dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Update successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Update failed"));
        }
    }

    // Fungsi untuk menghapus data absensi berdasarkan id
    public function deleteAbsensi($id)
    {
        // Query SQL untuk menghapus data absensi berdasarkan ID
        $sql = "DELETE FROM absensi WHERE id = :id";
        
        // Parameter untuk menghapus data berdasarkan id
        $params = array(":id" => $id);
        
        // Eksekusi query delete dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Delete successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Delete failed"));
        }
    }

    // Fungsi untuk mengambil daftar seluruh absensi
    public function getAbsensiList()
    {
        // Query SQL untuk mengambil semua data absensi
        $sql = 'SELECT * FROM absensi';
        
        // Mengembalikan hasil query dalam bentuk array asosiatif
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil data absensi dan mengirimkannya dalam format JSON
    public function getDataCombo()
    {
        // Query SQL untuk mengambil semua data absensi
        $sql = 'SELECT * FROM absensi';
        
        // Mengambil hasil query
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        
        // Menetapkan header sebagai JSON dan mengirimkan data sebagai JSON
        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
?>
