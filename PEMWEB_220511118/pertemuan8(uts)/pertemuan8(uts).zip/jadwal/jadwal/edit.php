<?php
// Memasukkan file controller dan fungsi tambahan
include("../controllers/Jadwal.php");
include("../lib/functions.php");

// Membuat objek controller untuk Jadwal
$obj = new JadwalController();

// Mengecek apakah ada parameter id yang dikirimkan melalui URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    // Jika tidak ada, arahkan pengguna ke halaman absensi.php
    header("Location: jadwal.php"); // Ganti dengan halaman yang sesuai
    exit; // Menghentikan eksekusi script setelah redirect
}

$msg = null; // Inisialisasi pesan kosong

// Mengecek apakah form telah disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $kodemk = $_POST["kodemk"];
    $matakuliah = $_POST["matakuliah"];
    $kelas = $_POST["kelas"];
    $hari = $_POST["hari"];
    $waktu = $_POST["waktu"];
    $ruangan = $_POST["ruangan"];
    $dosen = $_POST["dosen"];
    
    // Memanggil fungsi untuk melakukan update data absensi
    $dat = $obj->updateJadwal($id, $kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen);

    // Mengecek apakah update berhasil
    if ($dat) {
        $msg = 'Update Data Berhasil'; // Menampilkan pesan sukses
    } else {
        $msg = 'Update Gagal'; // Menampilkan pesan gagal
    }
}

// Mengambil data Jadwal yang akan diedit
$rows = $obj->getJadwal($id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Jadwal</title>
    <!-- Memasukkan TailwindCSS untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk menampilkan pesan sukses atau gagal selama 3 detik
        window.onload = function() {
            var msg = document.getElementById('msg');
            if (msg) {
                setTimeout(function() {
                    msg.style.display = 'none'; // Menyembunyikan pesan setelah 3 detik
                }, 3000);
            }
        };
    </script>
</head>
    <!-- Kontainer utama, memposisikan form di tengah layar -->
    <div class="flex justify-center items-center min-h-screen">
        <!-- Form untuk mengedit data Jadwal -->
        <div class="max-w-xs w-full bg-white rounded-lg shadow-lg p-4">
            <h1 class="text-xl font-semibold text-center mb-3">Edit Jadwal</h1>
            <p class="text-gray-600 text-center mb-4 text-sm">Perbarui Data Jadwal</p>

            <!-- Menampilkan pesan setelah proses update -->
            <?php 
            if (isset($msg)) {
                echo '<div id="msg" class="bg-green-500 text-white p-3 rounded mb-4 text-center text-xs">' . $msg . '</div>';
            }
            ?>

            <!-- Form untuk mengedit data Jadwal -->
            <form name="formEdit" method="POST" action="">
                <input type="hidden" name="submitted" value="1"/>
                <?php if ($rows) { $row = $rows[0]; ?>
                    <!-- Input ID Jadwal (readonly) -->
                    <div class="mb-3">
                        <label for="id" class="block text-xs font-medium text-gray-700">ID Jadwal</label>
                        <input type="text" id="id" name="id" value="<?php echo $row['id']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" readonly />
                    </div>

                    <!-- Input Kode Mata Kuliah (kodemk) -->
                    <div class="mb-3">
                        <label for="kodemk" class="block text-xs font-medium text-gray-700">Kode Mata Kuliah</label>
                        <input type="text" id="kodemk" name="kodemk" value="<?php echo $row['kodemk']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Mata Kuliah -->
                    <div class="mb-3">
                        <label for="matakuliah" class="block text-xs font-medium text-gray-700">Mata Kuliah</label>
                        <input type="text" id="matakuliah" name="matakuliah" value="<?php echo $row['matakuliah']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Kelas -->
                    <div class="mb-3">
                        <label for="kelas" class="block text-xs font-medium text-gray-700">Kelas</label>
                        <input type="text" id="kelas" name="kelas" value="<?php echo $row['kelas']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Hari -->
                    <div class="mb-3">
                        <label for="hari" class="block text-xs font-medium text-gray-700">Hari</label>
                        <input type="text" id="hari" name="hari" value="<?php echo $row['hari']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Waktu -->
                    <div class="mb-3">
                        <label for="waktu" class="block text-xs font-medium text-gray-700">Waktu</label>
                        <input type="text" id="waktu" name="waktu" value="<?php echo $row['waktu']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Ruangan -->
                    <div class="mb-3">
                        <label for="ruangan" class="block text-xs font-medium text-gray-700">Ruangan</label>
                        <input type="text" id="ruangan" name="ruangan" value="<?php echo $row['ruangan']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Dosen -->
                    <div class="mb-3">
                        <label for="dosen" class="block text-xs font-medium text-gray-700">Dosen</label>
                        <input type="text" id="dosen" name="dosen" value="<?php echo $row['dosen']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Tombol Update -->
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md">Update</button>
                <?php } else { ?>
                    <!-- Jika data Jadwal tidak ditemukan -->
                    <div class="text-red-500 text-center">Data Jadwal tidak ditemukan!</div>
                <?php } ?>

                <!-- Tombol Cancel untuk kembali ke halaman daftar absensi -->
            </form>
        </div>
    </div>
</body>
</html>
