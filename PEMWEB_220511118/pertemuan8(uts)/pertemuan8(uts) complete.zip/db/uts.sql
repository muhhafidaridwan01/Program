-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Des 2024 pada 23.33
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uts`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE `absensi` (
  `id` int(11) NOT NULL,
  `kodemk` varchar(10) NOT NULL,
  `matakuliah` varchar(100) NOT NULL,
  `pertemuanke` int(11) NOT NULL,
  `topik` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `absensi`
--

INSERT INTO `absensi` (`id`, `kodemk`, `matakuliah`, `pertemuanke`, `topik`) VALUES
(1, '001', 'Pemrograman Web', 8, 'UTS'),
(2, '002', 'Basis Data', 8, 'UTS'),
(3, '003', 'Tes Implementasi Sistem', 8, 'UTS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jadwal`
--

CREATE TABLE `jadwal` (
  `id` int(11) NOT NULL,
  `kodemk` varchar(10) NOT NULL,
  `matakuliah` varchar(100) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `hari` varchar(10) NOT NULL,
  `waktu` time NOT NULL,
  `ruangan` varchar(50) NOT NULL,
  `dosen` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jadwal`
--

INSERT INTO `jadwal` (`id`, `kodemk`, `matakuliah`, `kelas`, `hari`, `waktu`, `ruangan`, `dosen`) VALUES
(1, '001', 'Pemrograman Web', 'TI22C', 'Kamis', '10:00:00', 'Lab Komputer Gd. FKIP', 'Freddy Wicaksono, M.T'),
(2, '002', 'Basis Data', 'TI22C', 'Selasa', '13:00:00', 'Lab Komputer Gd. FKIP', 'Sabar Santoso, M.T'),
(3, '003', 'Tes Implementasi Sistem', 'TI22C', 'Rabu', '13:00:00', 'Gd. Djuanda Lt. 6', 'Agust Isa Martinus, M.T');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE `nilai` (
  `id` int(11) NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `matakuliah` varchar(100) NOT NULL,
  `nilai_kehadiran` int(11) NOT NULL,
  `nilai_tugas` int(11) NOT NULL,
  `nilai_uts` int(11) NOT NULL,
  `nilai_uas` int(11) NOT NULL,
  `nilai_akhir` int(11) GENERATED ALWAYS AS (`nilai_kehadiran` * 0.1 + `nilai_tugas` * 0.2 + `nilai_uts` * 0.3 + `nilai_uas` * 0.4) STORED,
  `mutu` char(2) GENERATED ALWAYS AS (case when `nilai_akhir` >= 85 then 'A' when `nilai_akhir` >= 75 then 'B' when `nilai_akhir` >= 65 then 'C' when `nilai_akhir` >= 50 then 'D' else 'E' end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `nilai`
--

INSERT INTO `nilai` (`id`, `nim`, `nama`, `matakuliah`, `nilai_kehadiran`, `nilai_tugas`, `nilai_uts`, `nilai_uas`) VALUES
(1, '001', 'Hafid', 'Pemrograman Mobile', 100, 90, 90, 90),
(2, '002', 'Fariz', 'Pemrograman Mobile', 60, 70, 85, 70),
(3, '003', 'Ubay', 'Pemrograman Mobile', 70, 80, 80, 75);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
