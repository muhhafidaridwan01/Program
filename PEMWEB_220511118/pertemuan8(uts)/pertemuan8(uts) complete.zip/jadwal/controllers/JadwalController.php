<?php
// Menyertakan file model JadwalModel.php yang berisi fungsi-fungsi untuk mengelola data Jadwal.
include_once('../models/JadwalModel.php');

// Mendefinisikan kelas JadwalController
class JadwalController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model JadwalModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new JadwalModel();
    }

    // Fungsi untuk menambahkan data Jadwal baru ke dalam database
    public function addJadwal($kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen)
    {
        // Memanggil fungsi addJadwal() dari model untuk menambahkan data Jadwal ke dalam database
        return $this->model->addJadwal($kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen);
    }

    // Fungsi untuk mengambil data Jadwal berdasarkan ID
    public function getJadwal($id)
    {
        // Memanggil fungsi getJadwal() dari model untuk mengambil data Jadwal berdasarkan ID
        return $this->model->getJadwal($id);
    }

    // Fungsi untuk menampilkan dosen Jadwal berdasarkan ID
    public function ShowJadwal($id)
    {
        // Mengambil data Jadwal berdasarkan ID
        $rows = $this->model->getJadwal($id);
        $val = null;
        
        // Loop untuk mendapatkan dosen Jadwal dari data yang didapat
        foreach ($rows as $row) {
            $val = $row;
        }
        
        // Mengembalikan dosen Jadwal
        return $val;
    }

    // Fungsi untuk memperbarui data Jadwal di database berdasarkan ID
    public function updateJadwal($id, $kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen)
    {
        // Memanggil fungsi updateJadwal() dari model untuk memperbarui data Jadwal
        return $this->model->updateJadwal($id, $kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen);
    }

    // Fungsi untuk menghapus data Jadwal berdasarkan ID
    public function deleteJadwal($id)
    {
        // Memanggil fungsi deleteJadwal() dari model untuk menghapus data Jadwal dari database
        return $this->model->deleteJadwal($id);
    }

    // Fungsi untuk mengambil daftar seluruh data Jadwal
    public function getJadwalList()
    {
        // Memanggil fungsi getJadwalList() dari model untuk mengambil semua data Jadwal
        return $this->model->getJadwalList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }

    // Fungsi untuk memeriksa duplikasi ID
    public function checkDuplicateId($id)
    {
        // Memanggil fungsi checkDuplicateId() dari model untuk memeriksa apakah ID sudah ada
        return $this->model->checkDuplicateId($id);
    }
}
?>
