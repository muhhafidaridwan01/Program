<?php
include_once('../db/database.php'); // Menyertakan file database untuk koneksi ke database

// Kelas AbsensiModel bertanggung jawab untuk melakukan operasi CRUD pada tabel 'absensi' di database
class JadwalModel
{
    private $db; // Properti untuk menyimpan objek koneksi database

    // Konstruktor kelas yang akan membuat objek koneksi ke database
    public function __construct()
    {
        $this->db = new Database(); // Membuat objek Database untuk koneksi ke DB
    }

    // Fungsi untuk menambahkan data absensi baru ke database
    public function addJadwal($kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen)
    {
        // Query SQL untuk menambahkan data absensi baru
        $sql = "INSERT INTO jadwal (kodemk, matakuliah, kelas, hari, waktu, ruangan, dosen) 
                VALUES (:kodemk, :matakuliah, :kelas, :hari, :waktu, :ruangan, :dosen)";
        
        // Parameter yang akan diganti pada query SQL
        $params = array(
            ":kodemk" => $kodemk,
            ":matakuliah" => $matakuliah,
            ":kelas" => $kelas,
            ":hari" => $hari,
            ":waktu" => $waktu,
            ":ruangan" => $ruangan,
            ":dosen" => $dosen,
        );

        // Eksekusi query dengan parameter yang telah diberikan
        $result = $this->db->executeQuery($sql, $params);
        
        // Mengecek apakah eksekusi berhasil dan mengembalikan hasil dalam format JSON
        if ($result) {
            return json_encode(array("success" => true, "message" => "Insert successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Insert failed"));
        }
    }

    // Fungsi untuk mengambil data absensi berdasarkan id
    public function getJadwal($id)
    {
        // Query SQL untuk mengambil data Jadwal berdasarkan ID
        $sql = "SELECT * FROM jadwal WHERE id = :id";
        
        // Parameter untuk mencari berdasarkan id
        $params = array(":id" => $id);
        
        // Mengembalikan data jadwal dalam bentuk array asosiatif
        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengupdate data jadwal berdasarkan id
    public function updateJadwal($id, $kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen)
    {
        // Query SQL untuk memperbarui data Jadwal
        $sql = "UPDATE jadwal
                SET kodemk = :kodemk, matakuliah = :matakuliah, kelas = :kelas, hari = :hari, 
                    waktu = :waktu, ruangan = :ruangan, dosen = :dosen
                WHERE id = :id";
        
        // Parameter yang akan digunakan untuk mengupdate data
        $params = array(
            ":kodemk" => $kodemk,
            ":matakuliah" => $matakuliah,
            ":kelas" => $kelas,
            ":hari" => $hari,
            ":waktu" => $waktu,
            ":ruangan" => $ruangan,
            ":dosen" => $dosen,
            ":id" => $id
        );

        // Eksekusi query update dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Update successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Update failed"));
        }
    }

    // Fungsi untuk menghapus data absensi berdasarkan id
    public function deleteJadwal($id)
    {
        // Query SQL untuk menghapus data absensi berdasarkan ID
        $sql = "DELETE FROM jadwal WHERE id = :id";
        
        // Parameter untuk menghapus data berdasarkan id
        $params = array(":id" => $id);
        
        // Eksekusi query delete dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Delete successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Delete failed"));
        }
    }

    // Fungsi untuk mengambil daftar seluruh data jadwal
    public function getJadwalList()
    {
        // Query SQL untuk mengambil semua data jadwal
        $sql = 'SELECT * FROM jadwal';
        
        // Mengembalikan hasil query dalam bentuk array asosiatif
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil data jadwal dan mengirimkannya dalam format JSON
    public function getDataCombo()
    {
        // Query SQL untuk mengambil semua data jadwal
        $sql = 'SELECT * FROM jadwal';
        
        // Mengambil hasil query
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        
        // Menetapkan header sebagai JSON dan mengirimkan data sebagai JSON
        header('Content-Type: application/json');
        echo json_encode($data);
    }

        // Fungsi untuk memeriksa duplikasi ID
        public function checkDuplicateId($id)
        {
            // Query SQL untuk memeriksa apakah ID sudah ada dalam tabel jadwal
            $sql = "SELECT COUNT(*) FROM jadwal WHERE id = :id";
            
            // Parameter untuk mencari berdasarkan id
            $params = array(":id" => $id);
            
            // Menjalankan query dan mengambil hasilnya
            $result = $this->db->executeQuery($sql, $params)->fetchColumn();
            
            // Jika hasilnya lebih dari 0, berarti ID sudah ada
            return $result > 0;
        }
}
?>
