<?php
// Menyertakan file database.php yang berisi class Database untuk koneksi ke database
include_once('../db/database.php');

// Membuat objek baru dari kelas Database untuk koneksi ke database
$db = new Database();

// Menyusun query SQL untuk mengambil semua data dari tabel 'karyawan'
$sql = "select * from jadwal ";  // Query untuk mengambil semua data dari tabel 'karyawan'

// Menjalankan query SQL yang telah disusun
$sql = 'SELECT * FROM jadwal'; // Query untuk mengambil seluruh data dari tabel 'karyawan'

// Eksekusi query dan mengambil hasilnya dalam bentuk array asosiatif
$result = $db->query($sql)->fetchAll(PDO::FETCH_ASSOC);

// Menetapkan header sebagai JSON agar hasil bisa dikirimkan dalam format JSON
header('Content-type: application/json');

// Mengirimkan hasil query dalam format JSON ke browser atau aplikasi yang memanggilnya
echo json_encode($result);
?>
