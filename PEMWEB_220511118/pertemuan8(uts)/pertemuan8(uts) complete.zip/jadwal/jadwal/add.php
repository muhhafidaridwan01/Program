<?php
include("../controllers/JadwalController.php"); // Menyertakan file controller untuk Karyawan
include("../lib/functions.php"); // Menyertakan file library untuk fungsi tambahan
$obj = new JadwalController(); // Membuat objek KaryawanController
$msg = null; // Menyimpan pesan yang akan ditampilkan

// Memproses form jika ada data POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data yang dikirim melalui form
    $kodemk = $_POST["kodemk"];
    $matakuliah = $_POST["matakuliah"];
    $kelas = $_POST["kelas"];
    $hari = $_POST["hari"];
    $waktu = $_POST["waktu"];
    $ruangan = $_POST["ruangan"];
    $dosen = $_POST["dosen"];
    
    // Menyimpan data ke database melalui controller
    $dat = $obj->addJadwal($kodemk, $matakuliah, $kelas, $hari, $waktu, $ruangan, $dosen);
    
    // Cek hasil dari proses insert data ke database
    if ($dat) {
        $msg = 'Insert Data Berhasil'; // Jika berhasil, tampilkan pesan sukses
    } else {
        $msg = 'Insert Gagal'; // Jika gagal, tampilkan pesan gagal
    }

    // Cek hasil dari proses insert data ke database
    if ($dat) {
        $msg = 'Insert Data Berhasil';
        header("Location: index.php"); // Arahkan ke halaman index.php
        exit();
    } else {
        $msg = 'Insert Gagal'; // Jika gagal, tampilkan pesan gagal
    }
}
?>

<html>
<head>
    <title>Jadwal</title> <!-- Judul halaman -->
    <script src="https://cdn.tailwindcss.com"></script> <!-- Menyertakan CDN Tailwind CSS untuk styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> <!-- Menyertakan CDN Font Awesome untuk ikon -->
    <script>
        // Fungsi untuk meng-clear form
        function clearForm() {
            document.forms["formAdd"].reset(); // Reset form untuk mengosongkan input
        }

        // Fungsi untuk menghilangkan pesan setelah beberapa detik
        function hideMessage() {
            setTimeout(function() {
                var messageElement = document.getElementById('message');
                if (messageElement) {
                    messageElement.style.display = 'none'; // Menyembunyikan pesan
                }
            }, 3000); // Menghilangkan pesan setelah 3 detik
        }
    </script>
</head>
    <div class="flex justify-center items-center h-screen"> <!-- Menyusun form di tengah layar -->
        <!-- Form -->
        <div class="max-w-sm w-full bg-white rounded-lg shadow-lg p-4 ml-[145px]">
            <!-- Kotak form dengan sedikit margin kiri -->
            <h1 class="text-xl font-semibold text-center mb-3">Jadwal</h1> <!-- Judul form -->
            <p class="text-gray-600 text-center mb-4 text-sm">Entry Data</p> <!-- Keterangan form -->

            <!-- Menampilkan pesan sukses atau gagal -->
            <?php if ($msg): ?>
                <div id="message" class="bg-<?php echo ($msg == 'Insert Data Berhasil') ? 'green' : 'red'; ?>-500 text-white p-3 rounded mb-4 text-center text-xs">
                    <?php echo $msg; ?> <!-- Menampilkan pesan status -->
                </div>
                <script>
                    hideMessage(); // Memanggil fungsi untuk menyembunyikan pesan setelah beberapa detik
                </script>
            <?php endif; ?>

            <form name="formAdd" method="POST" action=""> <!-- Form untuk input data Jadwal -->
                <div class="mb-3">
                    <label for="kodemk" class="block text-xs font-medium text-gray-700">Kode MK</label>
                    <input type="text" id="kodemk" name="kodemk" placeholder="Masukkan Kode MK" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Kode MK -->
                </div>
                <div class="mb-3">
                    <label for="matakuliah" class="block text-xs font-medium text-gray-700">Mata Kuliah</label>
                    <input type="text" id="matakuliah" name="matakuliah" placeholder="Masukkan Mata Kuliah" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Mata Kuliah -->
                </div>
                <div class="mb-3">
                    <label for="kelas" class="block text-xs font-medium text-gray-700">Kelas</label>
                    <input type="text" id="kelas" name="kelas" placeholder="Masukkan Kelas" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Kelas -->
                </div>
                <div class="mb-3">
                    <label for="hari" class="block text-xs font-medium text-gray-700">Hari</label>
                    <select id="hari" name="hari" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required> <!-- Dropdown untuk Hari -->
                        <option value="">--Pilih Hari--</option>
                        <option value="Senin">Senin</option>
                        <option value="Selasa">Selasa</option>
                        <option value="Rabu">Rabu</option>
                        <option value="Kamis">Kamis</option>
                        <option value="Jumat">Jumat</option>
                        <option value="Sabtu">Sabtu</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="waktu" class="block text-xs font-medium text-gray-700">Waktu</label>
                    <input type="time" id="waktu" name="waktu" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Waktu -->
                </div>
                <div class="mb-3">
                    <label for="ruangan" class="block text-xs font-medium text-gray-700">Ruangan</label>
                    <input type="text" id="ruangan" name="ruangan" placeholder="Masukkan Ruangan" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Ruangan -->
                </div>
                <div class="mb-3">
                    <label for="dosen" class="block text-xs font-medium text-gray-700">Dosen</label>
                    <input type="text" id="dosen" name="dosen" placeholder="Masukkan Dosen" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required /> <!-- Input untuk Dosen -->
                </div>
                <div class="flex justify-between">
                    <button class="bg-blue-500 text-white font-semibold py-2 px-4 rounded hover:bg-blue-600 text-xs" type="submit">Save</button> <!-- Tombol untuk menyimpan data -->
                    <button type="button" onclick="clearForm()" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400 text-xs">Clear</button> <!-- Tombol untuk membersihkan form -->
                </div>
            </form>
        </div>
    </div>
</body>
</html>
