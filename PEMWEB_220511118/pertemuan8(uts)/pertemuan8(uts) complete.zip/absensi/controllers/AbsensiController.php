<?php
// Menyertakan file model AbsensiModel.php yang berisi fungsi-fungsi untuk mengelola data Absensi.
include_once('../models/AbsensiModel.php');

// Mendefinisikan kelas AbsensiController
class AbsensiController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model AbsensiModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new AbsensiModel();
    }

    // Fungsi untuk menambahkan data Absensi baru ke dalam database
    public function addAbsensi($kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Memanggil fungsi addAbsensi() dari model untuk menambahkan data Absensi ke dalam database
        return $this->model->addAbsensi($kodemk, $matakuliah, $pertemuanke, $topik);
    }

    // Fungsi untuk mengambil data Absensi berdasarkan ID
    public function getAbsensi($id)
    {
        // Memanggil fungsi getAbsensi() dari model untuk mengambil data Absensi berdasarkan ID
        return $this->model->getAbsensi($id);
    }

    // Fungsi untuk menampilkan dosen Absensi berdasarkan ID
    public function ShowAbsensi($id)
    {
        // Mengambil data Absensi berdasarkan ID
        $rows = $this->model->getAbsensi($id);
        $val = null;
        
        // Loop untuk mendapatkan dosen Absensi dari data yang didapat
        foreach ($rows as $row) {
            $val = $row;
        }
        
        // Mengembalikan dosen Absensi
        return $val;
    }

    // Fungsi untuk memperbarui data Absensi di database berdasarkan ID
    public function updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik)
    {
        // Memanggil fungsi updateAbsensi() dari model untuk memperbarui data Absensi
        return $this->model->updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik);
    }

    // Fungsi untuk menghapus data Absensi berdasarkan ID
    public function deleteAbsensi($id)
    {
        // Memanggil fungsi deleteAbsensi() dari model untuk menghapus data Absensi dari database
        return $this->model->deleteAbsensi($id);
    }

    // Fungsi untuk mengambil daftar seluruh data Absensi
    public function getAbsensiList()
    {
        // Memanggil fungsi getAbsensiList() dari model untuk mengambil semua data Absensi
        return $this->model->getAbsensiList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }

    // Fungsi untuk memeriksa duplikasi ID
    public function checkDuplicateId($id)
    {
        // Memanggil fungsi checkDuplicateId() dari model untuk memeriksa apakah ID sudah ada
        return $this->model->checkDuplicateId($id);
    }
}
?>
