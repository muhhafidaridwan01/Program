<?php
// Memasukkan file controller dan fungsi tambahan
include("../controllers/AbsensiController.php");
include("../lib/functions.php");

// Membuat objek controller untuk Absensi
$obj = new AbsensiController();

// Mengecek apakah ada parameter id yang dikirimkan melalui URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    // Jika tidak ada, arahkan pengguna ke halaman absensi.php
    header("Location: absensi.php"); // Ganti dengan halaman yang sesuai
    exit; // Menghentikan eksekusi script setelah redirect
}

$msg = null; // Inisialisasi pesan kosong

// Mengecek apakah form telah disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $kodemk = $_POST["kodemk"];
    $matakuliah = $_POST["matakuliah"];
    $pertemuanke = $_POST["pertemuanke"];
    $topik = $_POST["topik"];
    
    // Memanggil fungsi untuk melakukan update data absensi
    $dat = $obj->updateAbsensi($id, $kodemk, $matakuliah, $pertemuanke, $topik);

    // Mengecek apakah update berhasil
    if ($dat) {
        $msg = 'Update Data Berhasil'; // Menampilkan pesan sukses
        // Redirect ke halaman index.php setelah berhasil update
        header("Location: index.php"); // Arahkan ke halaman index
        exit(); // Menghentikan eksekusi lebih lanjut
    } else {
        $msg = 'Update Gagal'; // Menampilkan pesan gagal
    }
}

// Mengambil data Jadwal yang akan diedit
$rows = $obj->getAbsensi($id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Absensi</title>
    <!-- Memasukkan TailwindCSS untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk menampilkan pesan sukses atau gagal selama 3 detik
        window.onload = function() {
            var msg = document.getElementById('msg');
            if (msg) {
                setTimeout(function() {
                    msg.style.display = 'none'; // Menyembunyikan pesan setelah 3 detik
                }, 3000);
            }
        };
    </script>
</head>
    <!-- Kontainer utama, memposisikan form di tengah layar -->
    <div class="flex justify-center items-center min-h-screen">
        <!-- Form untuk mengedit data Absensi -->
        <div class="max-w-xs w-full bg-white rounded-lg shadow-lg p-4">
            <h1 class="text-xl font-semibold text-center mb-3">Edit Absensi</h1>
            <p class="text-gray-600 text-center mb-4 text-sm">Perbarui Data Absensi</p>

            <!-- Menampilkan pesan setelah proses update -->
            <?php 
            if (isset($msg)) {
                echo '<div id="msg" class="bg-green-500 text-white p-3 rounded mb-4 text-center text-xs">' . $msg . '</div>';
            }
            ?>

            <!-- Form untuk mengedit data Absensi -->
            <form name="formEdit" method="POST" action="">
                <input type="hidden" name="submitted" value="1"/>
                <?php if ($rows) { $row = $rows[0]; ?>

                    <!-- Input Kode Mata Kuliah (kodemk) -->
                    <div class="mb-3">
                        <label for="kodemk" class="block text-xs font-medium text-gray-700">Kode Mata Kuliah</label>
                        <input type="text" id="kodemk" name="kodemk" value="<?php echo $row['kodemk']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Mata Kuliah -->
                    <div class="mb-3">
                        <label for="matakuliah" class="block text-xs font-medium text-gray-700">Mata Kuliah</label>
                        <input type="text" id="matakuliah" name="matakuliah" value="<?php echo $row['matakuliah']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Kelas -->
                    <div class="mb-3">
                        <label for="pertemuanke" class="block text-xs font-medium text-gray-700">Pertemuan Ke</label>
                        <input type="text" id="pertemuanke" name="pertemuanke" value="<?php echo $row['pertemuanke']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Hari -->
                    <div class="mb-3">
                        <label for="topik" class="block text-xs font-medium text-gray-700">Topik</label>
                        <input type="text" id="topik" name="topik" value="<?php echo $row['topik']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>
                    
                    <!-- Tombol Update -->
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md">Update</button>
                <?php } else { ?>
                    <!-- Jika data Absensi tidak ditemukan -->
                    <div class="text-red-500 text-center">Data Absensi tidak ditemukan!</div>
                <?php } ?>

                <!-- Tombol Cancel untuk kembali ke halaman daftar absensi -->
            </form>
        </div>
    </div>
</body>
</html>
