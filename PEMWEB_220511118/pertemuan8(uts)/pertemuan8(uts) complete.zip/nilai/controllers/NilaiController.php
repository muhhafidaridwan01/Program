<?php
// Menyertakan file model NilaiModel.php yang berisi fungsi-fungsi untuk mengelola data Nilai.
include_once('../models/NilaiModel.php');

// Mendefinisikan kelas NilaiController
class NilaiController
{
    // Mendeklarasikan properti untuk objek model
    private $model;

    // Konstruktor yang akan membuat objek model ketika controller ini dipanggil
    public function __construct()
    {
        // Membuat objek model NilaiModel untuk digunakan dalam fungsi-fungsi controller
        $this->model = new NilaiModel();
    }

    // Fungsi untuk menambahkan data Nilai baru ke dalam database
    public function addNilai($nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu)
    {
        // Memanggil fungsi addNilai() dari model untuk menambahkan data Nilai ke dalam database
        return $this->model->addNilai($nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu);
    }

    // Fungsi untuk mengambil data Nilai berdasarkan ID
    public function getNilai($id)
    {
        // Memanggil fungsi getNilai() dari model untuk mengambil data Nilai berdasarkan ID
        return $this->model->getNilai($id);
    }

    // Fungsi untuk menampilkan data Nilai berdasarkan ID
    public function showNilai($id)
    {
        // Mengambil data Nilai berdasarkan ID
        $rows = $this->model->getNilai($id);
        $val = null;
        
        // Loop untuk mendapatkan data Nilai dari data yang didapat
        foreach ($rows as $row) {
            $val = $row; // Mengambil seluruh data untuk ditampilkan
        }
        
        // Mengembalikan data Nilai
        return $val;
    }

    // Fungsi untuk memperbarui data Nilai di database berdasarkan ID
    public function updateNilai($id, $nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu)
    {
        // Memanggil fungsi updateNilai() dari model untuk memperbarui data Nilai
        return $this->model->updateNilai($id, $nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu);
    }

    // Fungsi untuk menghapus data Nilai berdasarkan ID
    public function deleteNilai($id)
    {
        // Memanggil fungsi deleteNilai() dari model untuk menghapus data Nilai dari database
        return $this->model->deleteNilai($id);
    }

    // Fungsi untuk mengambil daftar seluruh data Nilai
    public function getNilaiList()
    {
        // Memanggil fungsi getNilaiList() dari model untuk mengambil semua data Nilai
        return $this->model->getNilaiList();
    }

    // Fungsi untuk mengambil data kombinasi untuk keperluan form (seperti pilihan dropdown)
    public function getDataCombo()
    {
        // Memanggil fungsi getDataCombo() dari model untuk mengambil data kombinasi
        return $this->model->getDataCombo();
    }

    // Fungsi untuk memeriksa duplikasi ID
    public function checkDuplicateId($id)
    {
        // Memanggil fungsi checkDuplicateId() dari model untuk memeriksa apakah ID sudah ada
        return $this->model->checkDuplicateId($id);
    }
}
?>
