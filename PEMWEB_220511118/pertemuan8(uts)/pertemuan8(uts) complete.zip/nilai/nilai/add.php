<?php
include("../controllers/NilaiController.php"); // Menyertakan file controller untuk Karyawan
include("../lib/functions.php"); // Menyertakan file library untuk fungsi tambahan
$obj = new NilaiController(); // Membuat objek KaryawanController
$msg = null; // Menyimpan pesan yang akan ditampilkan

// Memproses form jika ada data POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data yang dikirim melalui form
    $nim = $_POST["nim"];
    $nama = $_POST["nama"];
    $matakuliah = $_POST["matakuliah"];
    $nilai_kehadiran = $_POST["nilai_kehadiran"];
    $nilai_tugas = $_POST["nilai_tugas"];
    $nilai_uts = $_POST["nilai_uts"];
    $nilai_uas = $_POST["nilai_uas"];

    // Menghitung nilai akhir berdasarkan formula
    $nilai_akhir = ($nilai_kehadiran * 0.1) + ($nilai_tugas * 0.2) + ($nilai_uts * 0.3) + ($nilai_uas * 0.4);

    // Menentukan mutu berdasarkan nilai akhir
    if ($nilai_akhir >= 85) {
        $mutu = 'A';
    } elseif ($nilai_akhir >= 75) {
        $mutu = 'B';
    } elseif ($nilai_akhir >= 65) {
        $mutu = 'C';
    } elseif ($nilai_akhir >= 50) {
        $mutu = 'D';
    } else {
        $mutu = 'E';
    }

    // Pastikan ID unik dengan memeriksa apakah sudah ada di database
    if ($obj->checkDuplicateId($id)) {
        $msg = 'ID sudah digunakan. Gunakan ID lain.';
    } else {
        // Menyimpan data ke database melalui controller
        $dat = $obj->addNilai($nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu);

        // Cek hasil dari proses insert data ke database
        if ($dat) {
            $msg = 'Insert Data Berhasil';
            header("Location: index.php"); // Arahkan ke halaman index.php
            exit();
        } else {
            $msg = 'Insert Gagal'; // Jika gagal, tampilkan pesan gagal
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nilai</title> <!-- Judul halaman -->
    <script src="https://cdn.tailwindcss.com"></script> <!-- Menyertakan CDN Tailwind CSS untuk styling -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"> <!-- Menyertakan CDN Font Awesome untuk ikon -->
    <script>
        // Fungsi untuk meng-clear form
        function clearForm() {
            document.forms["formAdd"].reset(); // Reset form untuk mengosongkan input
        }

        // Fungsi untuk menghilangkan pesan setelah beberapa detik
        function hideMessage() {
            setTimeout(function() {
                var messageElement = document.getElementById('message');
                if (messageElement) {
                    messageElement.style.display = 'none'; // Menyembunyikan pesan
                }
            }, 3000); // Menghilangkan pesan setelah 3 detik
        }
    </script>
</head>
<body>
    <div class="flex justify-center items-center h-screen"> <!-- Menyusun form di tengah layar -->
        <div class="max-w-sm w-full bg-white rounded-lg shadow-lg p-4 ml-[145px]"> <!-- Kotak form dengan sedikit margin kiri -->
            <h1 class="text-xl font-semibold text-center mb-3">Nilai</h1> <!-- Judul form -->
            <p class="text-gray-600 text-center mb-4 text-sm">Entry Data</p> <!-- Keterangan form -->

            <!-- Menampilkan pesan sukses atau gagal -->
            <?php if ($msg): ?>
                <div id="message" class="bg-<?php echo ($msg == 'Insert Data Berhasil') ? 'green' : 'red'; ?>-500 text-white p-3 rounded mb-4 text-center text-xs">
                    <?php echo htmlspecialchars($msg, ENT_QUOTES, 'UTF-8'); ?> <!-- Menampilkan pesan status -->
                </div>
                <script>
                    hideMessage(); // Memanggil fungsi untuk menyembunyikan pesan setelah beberapa detik
                </script>
            <?php endif; ?>

            <form name="formAdd" method="POST" action=""> <!-- Form untuk input data Nilai -->
                <div class="mb-3">
                    <label for="nim" class="block text-xs font-medium text-gray-700">NIM</label>
                    <input type="text" id="nim" name="nim" placeholder="Masukkan NIM" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="nama" class="block text-xs font-medium text-gray-700">Nama</label>
                    <input type="text" id="nama" name="nama" placeholder="Masukkan Nama" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="matakuliah" class="block text-xs font-medium text-gray-700">Mata Kuliah</label>
                    <input type="text" id="matakuliah" name="matakuliah" placeholder="Masukkan Mata Kuliah" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="nilai_kehadiran" class="block text-xs font-medium text-gray-700">Nilai Kehadiran</label>
                    <input type="number" id="nilai_kehadiran" name="nilai_kehadiran" placeholder="Masukkan Nilai Kehadiran" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="nilai_tugas" class="block text-xs font-medium text-gray-700">Nilai Tugas</label>
                    <input type="number" id="nilai_tugas" name="nilai_tugas" placeholder="Masukkan Nilai Tugas" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="nilai_uts" class="block text-xs font-medium text-gray-700">Nilai UTS</label>
                    <input type="number" id="nilai_uts" name="nilai_uts" placeholder="Masukkan Nilai UTS" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="mb-3">
                    <label for="nilai_uas" class="block text-xs font-medium text-gray-700">Nilai UAS</label>
                    <input type="number" id="nilai_uas" name="nilai_uas" placeholder="Masukkan Nilai UAS" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                </div>
                <div class="flex justify-between">
                    <button class="bg-blue-500 text-white font-semibold py-2 px-4 rounded hover:bg-blue-600 text-xs" type="submit">Save</button> <!-- Tombol untuk menyimpan data -->
                    <button type="button" onclick="clearForm()" class="bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded hover:bg-gray-400 text-xs">Clear</button> <!-- Tombol untuk membersihkan form -->
                </div>
            </form>
        </div>
    </div>
</body>
</html>
