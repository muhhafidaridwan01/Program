<?php
include("../controllers/NilaiController.php");
include("../lib/functions.php");
$obj = new NilaiController();

// Memproses penghapusan data
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $obj->deleteNilai($delete_id); // Panggil fungsi deleteNilai di controller
    header("Location: index.php"); // Setelah menghapus, arahkan kembali ke halaman index
    exit();
}

$rows = $obj->getNilaiList();
?>
<html>
<head>
    <title>Daftar Nilai</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="bg-gray-100 bg-opacity-50 p-6 min-h-screen">
        <div class="max-w-6xl mx-auto bg-white rounded-lg shadow-lg p-6">
            <h1 class="text-3xl font-bold mb-4 text-center">Daftar Nilai</h1>
            <p class="text-gray-600 text-center mb-6">List Data Nilai Mahasiswa</p>

            <a class="bg-green-500 text-white px-5 py-2 rounded shadow-md mb-4 inline-block hover:bg-green-600 transition duration-300" href="add.php">
                Tambah Data
            </a>

            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-blue-500 rounded-lg shadow-md">
                    <thead class="bg-blue-200">
                        <tr>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">ID</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">NIM</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nama</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Mata Kuliah</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nilai Kehadiran</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nilai Tugas</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nilai UTS</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nilai UAS</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Nilai Akhir</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-left">Mutu</th>
                            <th class="py-3 px-6 border-b border-blue-500 text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row) { ?>
                            <tr class="bg-white hover:bg-gray-100 transition duration-200">
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['id']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nim']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nama']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['matakuliah']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nilai_kehadiran']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nilai_tugas']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nilai_uts']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nilai_uas']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['nilai_akhir']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500"><?php echo $row['mutu']; ?></td>
                                <td class="py-3 px-6 border-b border-blue-500 text-center">
                                    <div class="flex space-x-6 justify-center">
                                        <a class="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition duration-300" href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                                        <!-- Tombol Hapus Data dengan Menambahkan Parameter delete_id -->
                                        <a class="bg-red-600 text-white px-6 py-2 rounded-md hover:bg-red-700 transition duration-300" href="?delete_id=<?php echo $row['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapusnya?');">
                                            Hapus
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
