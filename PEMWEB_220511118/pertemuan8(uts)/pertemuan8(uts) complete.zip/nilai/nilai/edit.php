<?php
// Memasukkan file controller dan fungsi tambahan
include("../controllers/NilaiController.php");
include("../lib/functions.php");

// Membuat objek controller untuk Nilai
$obj = new NilaiController();

// Mengecek apakah ada parameter id yang dikirimkan melalui URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];
} else {
    // Jika tidak ada, arahkan pengguna ke halaman nilai.php
    header("Location: nilai.php"); // Ganti dengan halaman yang sesuai
    exit; // Menghentikan eksekusi script setelah redirect
}

$msg = null; // Inisialisasi pesan kosong

// Mengecek apakah form telah disubmit (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nim = $_POST["nim"];
    $nama = $_POST["nama"];
    $matakuliah = $_POST["matakuliah"];
    $nilai_kehadiran = $_POST["nilai_kehadiran"];
    $nilai_tugas = $_POST["nilai_tugas"];
    $nilai_uts = $_POST["nilai_uts"];
    $nilai_uas = $_POST["nilai_uas"];
    $nilai_akhir = $_POST["nilai_akhir"];
    $mutu = $_POST["mutu"];
    
    // Memanggil fungsi untuk melakukan update data nilai
    $dat = $obj->updateNilai($id, $nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu);

    // Mengecek apakah update berhasil
    if ($dat) {
        $msg = 'Update Data Berhasil'; // Menampilkan pesan sukses
        // Redirect ke halaman index.php setelah berhasil update
        header("Location: index.php"); // Arahkan ke halaman index
        exit(); // Menghentikan eksekusi lebih lanjut
    } else {
        $msg = 'Update Gagal'; // Menampilkan pesan gagal
    }
}

// Mengambil data Nilai yang akan diedit
$rows = $obj->getNilai($id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Nilai</title>
    <!-- Memasukkan TailwindCSS untuk styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        // Fungsi untuk menampilkan pesan sukses atau gagal selama 3 detik
        window.onload = function() {
            var msg = document.getElementById('msg');
            if (msg) {
                setTimeout(function() {
                    msg.style.display = 'none'; // Menyembunyikan pesan setelah 3 detik
                }, 3000);
            }
        };
    </script>
</head>
<body>
    <!-- Kontainer utama, memposisikan form di tengah layar -->
    <div class="flex justify-center items-center min-h-screen">
        <!-- Form untuk mengedit data Nilai -->
        <div class="max-w-xs w-full bg-white rounded-lg shadow-lg p-4">
            <h1 class="text-xl font-semibold text-center mb-3">Edit Nilai</h1>
            <p class="text-gray-600 text-center mb-4 text-sm">Perbarui Data Nilai</p>

            <!-- Menampilkan pesan setelah proses update -->
            <?php 
            if (isset($msg)) {
                echo '<div id="msg" class="bg-green-500 text-white p-3 rounded mb-4 text-center text-xs">' . $msg . '</div>';
            }
            ?>

            <!-- Form untuk mengedit data Nilai -->
            <form name="formEdit" method="POST" action="">
                <input type="hidden" name="submitted" value="1"/>
                <?php if ($rows) { $row = $rows[0]; ?>

                    <!-- Input NIM (nim) -->
                    <div class="mb-3">
                        <label for="nim" class="block text-xs font-medium text-gray-700">NIM</label>
                        <input type="text" id="nim" name="nim" value="<?php echo $row['nim']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nama -->
                    <div class="mb-3">
                        <label for="nama" class="block text-xs font-medium text-gray-700">Nama</label>
                        <input type="text" id="nama" name="nama" value="<?php echo $row['nama']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Mata Kuliah -->
                    <div class="mb-3">
                        <label for="matakuliah" class="block text-xs font-medium text-gray-700">Mata Kuliah</label>
                        <input type="text" id="matakuliah" name="matakuliah" value="<?php echo $row['matakuliah']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nilai Kehadiran -->
                    <div class="mb-3">
                        <label for="nilai_kehadiran" class="block text-xs font-medium text-gray-700">Nilai Kehadiran</label>
                        <input type="text" id="nilai_kehadiran" name="nilai_kehadiran" value="<?php echo $row['nilai_kehadiran']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nilai Tugas -->
                    <div class="mb-3">
                        <label for="nilai_tugas" class="block text-xs font-medium text-gray-700">Nilai Tugas</label>
                        <input type="text" id="nilai_tugas" name="nilai_tugas" value="<?php echo $row['nilai_tugas']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>
                    
                    <!-- Input Nilai UTS -->
                    <div class="mb-3">
                        <label for="nilai_uts" class="block text-xs font-medium text-gray-700">Nilai UTS</label>
                        <input type="text" id="nilai_uts" name="nilai_uts" value="<?php echo $row['nilai_uts']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>

                    <!-- Input Nilai UAS -->
                    <div class="mb-3">
                        <label for="nilai_uas" class="block text-xs font-medium text-gray-700">Nilai UAS</label>
                        <input type="text" id="nilai_uas" name="nilai_uas" value="<?php echo $row['nilai_uas']; ?>" class="mt-1 block w-full border-2 border-blue-300 rounded-md shadow-sm focus:ring focus:ring-blue-500 p-1.5 text-xs" required />
                    </div>
                
                    <!-- Tombol Update -->
                    <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md">Update</button>
                <?php } else { ?>
                    <!-- Jika data Nilai tidak ditemukan -->
                    <div class="text-red-500 text-center">Data Nilai tidak ditemukan!</div>
                <?php } ?>
            </form>
        </div>
    </div>
</body>
</html>
