<?php
include_once('../db/database.php'); // Menyertakan file database untuk koneksi ke database

// Kelas NilaiModel bertanggung jawab untuk melakukan operasi CRUD pada tabel 'nilai' di database
class NilaiModel
{
    private $db; // Properti untuk menyimpan objek koneksi database

    // Konstruktor kelas yang akan membuat objek koneksi ke database
    public function __construct()
    {
        $this->db = new Database(); // Membuat objek Database untuk koneksi ke DB
    }

    // Fungsi untuk menambahkan data nilai baru ke database
    public function addNilai($nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu)
    {
        // Query SQL untuk menambahkan data nilai baru
        $sql = "INSERT INTO nilai (nim, nama, matakuliah, nilai_kehadiran, nilai_tugas, nilai_uts, nilai_uas, nilai_akhir, mutu) 
                VALUES (:nim, :nama, :matakuliah, :nilai_kehadiran, :nilai_tugas, :nilai_uts, :nilai_uas, :nilai_akhir, :mutu)";
        
        // Parameter yang akan diganti pada query SQL
        $params = array(
            ":nim" => $nim,
            ":nama" => $nama,
            ":matakuliah" => $matakuliah,
            ":nilai_kehadiran" => $nilai_kehadiran,
            ":nilai_tugas" => $nilai_tugas,
            ":nilai_uts" => $nilai_uts,
            ":nilai_uas" => $nilai_uas,
            ":nilai_akhir" => $nilai_akhir,
            ":mutu" => $mutu,
        );

        // Eksekusi query dengan parameter yang telah diberikan
        $result = $this->db->executeQuery($sql, $params);
        
        // Mengecek apakah eksekusi berhasil dan mengembalikan hasil dalam format JSON
        if ($result) {
            return json_encode(array("success" => true, "message" => "Insert successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Insert failed"));
        }
    }

    // Fungsi untuk mengambil data nilai berdasarkan id
    public function getNilai($id)
    {
        // Query SQL untuk mengambil data nilai berdasarkan ID
        $sql = "SELECT * FROM nilai WHERE id = :id";
        
        // Parameter untuk mencari berdasarkan id
        $params = array(":id" => $id);
        
        // Mengembalikan data nilai dalam bentuk array asosiatif
        return $this->db->executeQuery($sql, $params)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengupdate data nilai berdasarkan id
    public function updateNilai($id, $nim, $nama, $matakuliah, $nilai_kehadiran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $mutu)
    {
        // Query SQL untuk memperbarui data nilai
        $sql = "UPDATE nilai
                SET nim = :nim, nama = :nama, matakuliah = :matakuliah, nilai_kehadiran = :nilai_kehadiran, 
                    nilai_tugas = :nilai_tugas, nilai_uts = :nilai_uts, nilai_uas = :nilai_uas, 
                    nilai_akhir = :nilai_akhir, mutu = :mutu
                WHERE id = :id";
        
        // Parameter yang akan digunakan untuk mengupdate data
        $params = array(
            ":nim" => $nim,
            ":nama" => $nama,
            ":matakuliah" => $matakuliah,
            ":nilai_kehadiran" => $nilai_kehadiran,
            ":nilai_tugas" => $nilai_tugas,
            ":nilai_uts" => $nilai_uts,
            ":nilai_uas" => $nilai_uas,
            ":nilai_akhir" => $nilai_akhir,
            ":mutu" => $mutu,
            ":id" => $id
        );

        // Eksekusi query update dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Update successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Update failed"));
        }
    }

    // Fungsi untuk menghapus data nilai berdasarkan id
    public function deleteNilai($id)
    {
        // Query SQL untuk menghapus data nilai berdasarkan ID
        $sql = "DELETE FROM nilai WHERE id = :id";
        
        // Parameter untuk menghapus data berdasarkan id
        $params = array(":id" => $id);
        
        // Eksekusi query delete dan mengembalikan hasil dalam format JSON
        $result = $this->db->executeQuery($sql, $params);
        if ($result) {
            return json_encode(array("success" => true, "message" => "Delete successful"));
        } else {
            return json_encode(array("success" => false, "message" => "Delete failed"));
        }
    }

    // Fungsi untuk mengambil daftar seluruh data nilai
    public function getNilaiList()
    {
        // Query SQL untuk mengambil semua data nilai
        $sql = 'SELECT * FROM nilai';
        
        // Mengembalikan hasil query dalam bentuk array asosiatif
        return $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }

    // Fungsi untuk mengambil data nilai dan mengirimkannya dalam format JSON
    public function getDataCombo()
    {
        // Query SQL untuk mengambil semua data nilai
        $sql = 'SELECT * FROM nilai';
        
        // Mengambil hasil query
        $data = $this->db->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        
        // Menetapkan header sebagai JSON dan mengirimkan data sebagai JSON
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    // Fungsi untuk memeriksa duplikasi ID
    public function checkDuplicateId($id)
    {
        // Query SQL untuk memeriksa apakah ID sudah ada dalam tabel nilai
        $sql = "SELECT COUNT(*) FROM nilai WHERE id = :id";
        
        // Parameter untuk mencari berdasarkan id
        $params = array(":id" => $id);
        
        // Menjalankan query dan mengambil hasilnya
        $result = $this->db->executeQuery($sql, $params)->fetchColumn();
        
        // Jika hasilnya lebih dari 0, berarti ID sudah ada
        return $result > 0;
    }
}
?>
